# Tell Vivado that your input port "clk_sys" will be driven at 300 MHz (3.333 ns period)
# Replace 'clk_sys' with the exact name of the clock input in your top verilog module.
create_clock -period 3.333 -name sys_clk_pin -waveform {0.000 1.667} [get_ports clk_mem]