module switch_8_port #(
    parameter N = 16,               // Number of Ports
    parameter PD_WIDTH = 11,        // Packet Data Width
    parameter DEPTH_LOG = 11,       
    parameter N_16_WIDTH = 11,
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 7), // Total slots
    parameter K = 8  
)(
    // --- Clocks & Reset ---
    // input wire clk_sys,          // <--- REMOVED (Generated internally)
    input wire clk_mem,     
          
    input wire rst_n,
    input wire clk_sys,
    // --- Control Inputs ---
    input wire [N-1:0] we_in,       
    
    // Egress Port Indications
    input wire [2:0] eg_port_in_0,  input wire [2:0] eg_port_in_1,
    input wire [2:0] eg_port_in_2,  input wire [2:0] eg_port_in_3,
    input wire [2:0] eg_port_in_4,  input wire [2:0] eg_port_in_5,
    input wire [2:0] eg_port_in_6,  input wire [2:0] eg_port_in_7,
    
    // Port B Output (Stats)
    output wire [15:0] egress_port_0,  output wire [15:0] egress_port_1,
    output wire [15:0] egress_port_2,  output wire [15:0] egress_port_3,
    output wire [15:0] egress_port_4,  output wire [15:0] egress_port_5,
    output wire [15:0] egress_port_6,  output wire [15:0] egress_port_7
);

    // =========================================================================
    // 1. CLOCK GENERATION (Dedicated Variable)
    // =========================================================================
    

    reg [2:0] tdm_idx; // Independent variable
    
    // =========================================================================
    // 2. INTERNAL SIGNALS & WIRES
    // =========================================================================
    wire [(N * PD_WIDTH * N) - 1 : 0] egress_sched_out_flat;
    wire [N-1:0] wac_valid_we; 
    wire [$clog2(TOTAL_MEM_CAPACITY):0] shared_pool_left;
    reg [N-1:0] obm_we_a;                   
    wire [N*(DEPTH_LOG)-1 : 0] q_len_flat;
    wire [N-1:0] q_not_empty;
    
    reg [15:0] egress_pkt_count[0:N-1];

    // --- eg_ports_flat Definition ---
    wire [N*$clog2(N)-1 : 0] eg_ports_flat;
    
    assign eg_ports_flat = {
        eg_port_in_7,  eg_port_in_6,  eg_port_in_5,  eg_port_in_4,
        eg_port_in_3,  eg_port_in_2,  eg_port_in_1,  eg_port_in_0
    };

    // Output Assignments
    assign egress_port_0 = egress_pkt_count[0];
    assign egress_port_1 = egress_pkt_count[1];
    assign egress_port_2 = egress_pkt_count[2];
    assign egress_port_3 = egress_pkt_count[3];
    assign egress_port_4 = egress_pkt_count[4];
    assign egress_port_5 = egress_pkt_count[5];
    assign egress_port_6 = egress_pkt_count[6];
    assign egress_port_7 = egress_pkt_count[7];
    

    // =========================================================================
    // 3. WAC INSTANTIATION
    // =========================================================================
    wac_8_port #(.N(N), .DEPTH_LOG(DEPTH_LOG),.TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY)) u_wac (
        .clk(clk_sys), // Connected to our new internal clock
        .we(we_in),
        // Connect inputs explicitly
        .eg_port_0(eg_port_in_0), .eg_port_1(eg_port_in_1), .eg_port_2(eg_port_in_2), .eg_port_3(eg_port_in_3),
        .eg_port_4(eg_port_in_4), .eg_port_5(eg_port_in_5), .eg_port_6(eg_port_in_6), .eg_port_7(eg_port_in_7),
        .left(shared_pool_left),
        .q_len_flat(q_len_flat),
        .valid_we(wac_valid_we),
        .alpha(5'd16), 
        .invert(1'd0)
    );


    // =========================================================================
    // 4. INTERNAL PACKET GENERATOR & TDM CONTROLLER
    // =========================================================================
    
    reg [PD_WIDTH-1:0] shared_data_bus; 
    
    integer k;
    localparam PAD_WIDTH = PD_WIDTH - 6;

    always @(posedge clk_mem or negedge rst_n) begin
        if (!rst_n) begin
            tdm_idx <= 0;
            obm_we_a <= 0;
            shared_data_bus <= 0;
            for (k = 0; k < N; k = k + 1) begin
                egress_pkt_count[k] <= 16'd0;
            end
        end else begin
            // A. Cycle TDM Index (Next Source)
            tdm_idx <= tdm_idx + 1;

            // B. Stats Counters
            for (k = 0; k < N; k = k + 1) begin
                if (q_not_empty[k]) begin
                    egress_pkt_count[k] <= egress_pkt_count[k] + 1;
                end
            end

            // C. Data Bus Generation
            shared_data_bus <= { 
                {PAD_WIDTH{1'b0}}, 
                eg_ports_flat[ tdm_idx*3 +: 3 ], 
                tdm_idx 
            };

            // D. Write Decoder
            for (k = 0; k < N; k = k + 1) begin
                obm_we_a[k] <= 1'b0; // Default OFF
                
                if ( (k == eg_ports_flat[ tdm_idx*3 +: 3 ]) && wac_valid_we[tdm_idx] ) begin
                    obm_we_a[k] <= 1'b1;
                end
            end
        end
    end

    wire read_pulse = (tdm_idx == 4'd7);
    
    //==========================================================================
    // Shared Pool Manager
    //==========================================================================
    pool_manager #(
    N,
    DEPTH_LOG,
    TOTAL_MEM_CAPACITY) s_p 
    (
    .clk_mem(clk_mem),
    .rst_n(rst_n),
    .obm_we_a(obm_we_a),
    .read_pulse(read_pulse),
    .shared_pool_left(shared_pool_left),
    .q_not_empty(q_not_empty),
    .tdm_idx(tdm_idx)
    );

    // =========================================================================
    // 6. DT QUEUES (The Memory)
    // =========================================================================
    
    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : obm_inst
            dt_queue #(
                .PD_WIDTH(PD_WIDTH),
                .N(N),
                .DEPTH_LOG(DEPTH_LOG)
            ) u_queue (
                .clk(clk_mem),
                .rst_n(rst_n),
                
                // Port A (Write)
                .we_a(obm_we_a[i]),
                .din_a(shared_data_bus), 
                
                // Port B (Read)
                .dout_b(egress_sched_out_flat[i*(PD_WIDTH*N) +: (PD_WIDTH*N)]), 
                .re_b(read_pulse),
                .valid_out(q_not_empty[i]),
                .tdm_idx(tdm_idx),
                
                // Status
                .current_len(q_len_flat[i*(DEPTH_LOG) +: (DEPTH_LOG)])
            );
        end
    endgenerate

endmodule