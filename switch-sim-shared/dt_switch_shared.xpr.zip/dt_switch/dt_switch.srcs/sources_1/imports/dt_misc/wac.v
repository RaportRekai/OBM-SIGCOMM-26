module wac #(
    parameter N = 16, 
    parameter DEPTH_LOG = 11,
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 7)
)(
    input  wire clk,
    input  wire [N-1:0] we,
    
    // Flattened Egress Port Destinations
    input  wire [$clog2(N)-1:0] eg_port_0,
    input  wire [$clog2(N)-1:0] eg_port_1,
    input  wire [$clog2(N)-1:0] eg_port_2,
    input  wire [$clog2(N)-1:0] eg_port_3,
    input  wire [$clog2(N)-1:0] eg_port_4,
    input  wire [$clog2(N)-1:0] eg_port_5,
    input  wire [$clog2(N)-1:0] eg_port_6,
    input  wire [$clog2(N)-1:0] eg_port_7,
    input  wire [$clog2(N)-1:0] eg_port_8,
    input  wire [$clog2(N)-1:0] eg_port_9,
    input  wire [$clog2(N)-1:0] eg_port_10,
    input  wire [$clog2(N)-1:0] eg_port_11,
    input  wire [$clog2(N)-1:0] eg_port_12,
    input  wire [$clog2(N)-1:0] eg_port_13,
    input  wire [$clog2(N)-1:0] eg_port_14,
    input  wire [$clog2(N)-1:0] eg_port_15,
    
    // --- CONTROL INPUTS ---
    input  wire invert,      // NEW: 0 = Multiply (<<), 1 = Divide (>>)
    input  wire [4:0] alpha, // Shift factor 
    
    input  wire [N*(DEPTH_LOG)-1:0] q_len_flat, 
    input  wire [$clog2(TOTAL_MEM_CAPACITY):0] left,
    
    // Outputs
    output wire [N-1:0] valid_we
);

    // 1. Array Packing for Egress Ports
    wire [$clog2(N)-1:0] eg_port [0:N-1];
    assign eg_port[0] = eg_port_0;   assign eg_port[1] = eg_port_1;       
    assign eg_port[2] = eg_port_2;   assign eg_port[3] = eg_port_3;
    assign eg_port[4] = eg_port_4;   assign eg_port[5] = eg_port_5;
    assign eg_port[6] = eg_port_6;   assign eg_port[7] = eg_port_7;
    assign eg_port[8] = eg_port_8;   assign eg_port[9] = eg_port_9;
    assign eg_port[10] = eg_port_10; assign eg_port[11] = eg_port_11;
    assign eg_port[12] = eg_port_12; assign eg_port[13] = eg_port_13;
    assign eg_port[14] = eg_port_14; assign eg_port[15] = eg_port_15;

    // 2. Unpack Queue Lengths
    wire [DEPTH_LOG-1:0] all_q_len [0:N-1];
    genvar j;
    generate
        for (j=0; j<N; j=j+1) begin : unpack_len
            assign all_q_len[j] = q_len_flat[j*(DEPTH_LOG) +: (DEPTH_LOG)];
        end
    endgenerate

    // 3. Dynamic Threshold Calculation
    // -------------------------------------------------------------------------
    // Use 32 bits to safely handle Left Shifts without overflow/truncation.
    // Logic:
    //   If invert == 0: Threshold = left << alpha (Multiply by 2^alpha)
    //   If invert == 1: Threshold = left >> alpha (Divide by 2^alpha)
    // -------------------------------------------------------------------------
    wire [31:0] dynamic_threshold;
    
    assign dynamic_threshold = invert ? (left >> alpha) : (left << alpha);

    // 4. Per-Port Admission Logic
    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : admission_logic
            
            // A. Identify destination
            wire [$clog2(N)-1:0] my_dest_idx = eg_port[i];
            
            // B. Get CURRENT length
            wire [DEPTH_LOG-1:0] my_dest_len = all_q_len[my_dest_idx];

            // C. Check Threshold (Policy)
            //    We check if the current length is strictly LESS than the allowed threshold.
            //    Note: Comparing 11-bit length vs 32-bit threshold works fine in Verilog.
            wire is_under_threshold = (my_dest_len < dynamic_threshold);

            // D. Assign Output
            //    Admit if User Wants Write (we) AND We are under the limit.
            assign valid_we[i] = we[i] && is_under_threshold && (left > i+1);

        end
    endgenerate

endmodule