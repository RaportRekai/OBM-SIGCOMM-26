module pool_manager #(
    parameter N = 16,
    parameter DEPTH_LOG = 11,
    parameter TOTAL_MEM_CAPACITY = 16 * 128
)(
    input wire clk_mem,
    input wire rst_n,

    // Ingress & Drop Interface
    input wire [N-1:0] obm_we_a,         

    // Egress Interface
    input wire read_pulse,              
    input wire [N-1:0] q_not_empty,     
    input wire [$clog2(N)-1:0]tdm_idx,
    // Output
    output reg signed [$clog2(TOTAL_MEM_CAPACITY)+1:0] shared_pool_left
);

    // 1. Detect Ingress Events
    wire packet_stored; 
    assign packet_stored = |(obm_we_a);
    

    // 2. Egress Logic (Combinational Look-Ahead)
    reg [N-1:0] egress_todo_mask;
    reg [N-1:0] next_egress_mask;
    reg process_egress_now;

    // Use a delayed read pulse to align with the start of the new TDM window
    reg delayed_read_pulse;
    always @(posedge clk_mem or negedge rst_n) begin
        if (!rst_n) delayed_read_pulse <= 0;
        else        delayed_read_pulse <= read_pulse;
    end

    // --- PURELY COMBINATIONAL LOGIC ---
    always @* begin
        // Default: Hold current mask, don't process
        next_egress_mask = egress_todo_mask;
        process_egress_now = 0;

        if (delayed_read_pulse) begin
            // CASE A: Start of Window (Load & Process immediately)
            if (q_not_empty != 0) begin
                // We have data! Process one bit NOW.
                process_egress_now = 1;
                // Store the REST of the bits for next cycles
                next_egress_mask = q_not_empty & (q_not_empty - 1);
            end else begin
                // No data, clear mask
                next_egress_mask = 0;
            end
        end else begin
            // CASE B: Middle of Window (Continue Processing)
            if (egress_todo_mask != 0) begin
                process_egress_now = 1;
                // Clear the LSB we just processed
                next_egress_mask = egress_todo_mask & (egress_todo_mask - 1);
            end
        end
    end

    // 3. Calculate Change (Combinational)
    // Now that process_egress_now is combinatorial, this is valid for the current clock edge
    wire [2:0] slct = {packet_stored, process_egress_now};
    reg signed [$clog2(N)+1:0] change;

    always @* begin
        case (slct)
            3'b00: change = 0;                     // Idle
            3'b01: change = 1;           // Drop Only (+K)
            3'b10: change = -1;                     // Left Only (+1)
            3'b11: change = 0;       // Drop + Left (+K+1)
        endcase
    end

    // 4. Sequential Update
    // 4. Sequential Update
    always @(posedge clk_mem or negedge rst_n) begin
        if (!rst_n) begin
            shared_pool_left <= TOTAL_MEM_CAPACITY;
            egress_todo_mask <= 0;
        end else begin
            // Update the mask based on the combinatorial logic above
            egress_todo_mask <= next_egress_mask;

            // Update the pool
            // CHANGED: Added (shared_pool_left + change >= 0) to prevent underflow
            if ( (shared_pool_left + change <= TOTAL_MEM_CAPACITY) && 
                 (shared_pool_left + change >= 0) ) begin
                 
                shared_pool_left <= shared_pool_left + change;
            end
        end
    end

endmodule