module dt_queue #(
    parameter PD_WIDTH = 18,    // Packet Width (18 bits)
    parameter N = 16,           // Banking Factor
    parameter DEPTH_LOG = 11    // Total Depth (1024 packets)
)(
    input wire clk,
    input wire rst_n,

    // --- PORT A (Tail / Write) ---
    input wire we_a,                    
    input wire [PD_WIDTH-1:0] din_a,   

    // --- PORT B (Head / Read) ---
    input wire re_b,                    
    output wire [PD_WIDTH*N-1:0] dout_b,
    // --- NEW: Queue Status ---
    output reg [DEPTH_LOG-1:0] current_len, // Output width is DEPTH_LOG+1 (0 to 1024)
    output reg valid_out,
    input wire [$clog2(N)-1:0]tdm_idx
);

    // =========================================================
    // 1. POINTERS
    // =========================================================
    reg [DEPTH_LOG-1:0] w_ptr;
    reg [DEPTH_LOG-1:0] r_ptr;
    wire is_empty;
    assign is_empty = (w_ptr == r_ptr);
    assign r_ptr_out = r_ptr;
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            w_ptr <= 0;
            valid_out<=0;
            r_ptr <= 0;
        end else begin
            // Tail Logic
            if (we_a) begin
                w_ptr <= w_ptr + 1;      
            end

            // Head Logic
            if (re_b && !is_empty) begin
                r_ptr <= r_ptr + 1;
                valid_out <= 1'b1; // Pulse valid for 1 cycle
            end else begin
                valid_out <= 1'b0;
            end
        end
    end

    // =========================================================
    // 2. LENGTH CALCULATION
    // =========================================================
    // We calculate this combinatorially (instant update) 
    // or sequentially (registered) depending on timing needs.
    // Registered is safer for high-speed designs.
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_len <= 0;
        end else begin
            // Calculate Next State Pointers to get 'instant' length for next cycle
            // Or simply subtract current pointers:
            // Verilog handles wrap-around automatically (e.g. 2 - 1023 = 3).
            current_len <= (w_ptr - r_ptr);
        end
    end
    
    // Note: If you need strictly accurate length *during* the cycle a write happens,
    // you would need slightly more complex logic:
    // next_len = (w_ptr_next - r_ptr_next).
    // But usually, a 1-cycle delayed length report is standard for FIFO status.

    // =========================================================
    // 3. ADDRESS DECODING & MEMORY (Same as before)
    // =========================================================
    localparam ROW_BITS = DEPTH_LOG - $clog2(N);
    localparam BANK_BITS = $clog2(N);

    wire [ROW_BITS-1:0]   tail_row  = w_ptr[DEPTH_LOG-1 : BANK_BITS];
    wire [BANK_BITS-1:0]  tail_bank = w_ptr[BANK_BITS-1 : 0];
    wire [ROW_BITS-1:0]   head_row  = r_ptr[DEPTH_LOG-1 : BANK_BITS];

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : banks
            
            reg [PD_WIDTH-1:0] mem_array [0:(1<<ROW_BITS)-1];
            reg [PD_WIDTH-1:0] bank_out_a;
            reg [PD_WIDTH-1:0] bank_out_b;

            always @(posedge clk) begin
                // Write Port
                if (we_a  && (tail_bank == i)) begin
                    mem_array[tail_row] <= din_a;
                end
            
                if (re_b) begin
                    bank_out_b <= mem_array[head_row];
                end
             end
            assign dout_b[i*PD_WIDTH +: PD_WIDTH] = bank_out_b;
          end     
     endgenerate
endmodule
