`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 01/30/2026 02:18:22 PM
// Design Name: 
// Module Name: tb_switch
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module tb_switch_top;

    // =========================================================================
    // 1. PARAMETERS (Must match switch_top)
    // =========================================================================
    parameter N = 16;
    parameter PD_WIDTH = 18;
    parameter DEPTH_LOG = 10;
    parameter N_16_WIDTH = 8;
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 10);
    parameter K = 4;

    // =========================================================================
    // 2. SIGNALS
    // =========================================================================
    reg clk_sys;
    reg clk_mem;
    reg rst_n;
    reg [N-1:0] we_in;

    // Individual Destination Port Signals
    reg [3:0] eg_port_0,  eg_port_1,  eg_port_2,  eg_port_3;
    reg [3:0] eg_port_4,  eg_port_5,  eg_port_6,  eg_port_7;
    reg [3:0] eg_port_8,  eg_port_9,  eg_port_10, eg_port_11;
    reg [3:0] eg_port_12, eg_port_13, eg_port_14, eg_port_15;

    // Outputs
    
    wire [PD_WIDTH-1:0] egress_port_0;
    wire [PD_WIDTH-1:0] egress_port_1;
    wire [PD_WIDTH-1:0] egress_port_2;
    wire [PD_WIDTH-1:0] egress_port_3;
    wire [PD_WIDTH-1:0] egress_port_4;
    wire [PD_WIDTH-1:0] egress_port_5;
    wire [PD_WIDTH-1:0] egress_port_6;
    wire [PD_WIDTH-1:0] egress_port_7;
    wire [PD_WIDTH-1:0] egress_port_8;
    wire [PD_WIDTH-1:0] egress_port_9;
    wire [PD_WIDTH-1:0] egress_port_10;
    wire [PD_WIDTH-1:0] egress_port_11;
    wire [PD_WIDTH-1:0] egress_port_12;
    wire [PD_WIDTH-1:0] egress_port_13;
    wire [PD_WIDTH-1:0] egress_port_14;
    wire [PD_WIDTH-1:0] egress_port_15;
    wire [3:0]current_bank_sel;

    // =========================================================================
    // 3. DUT INSTANTIATION
    // =========================================================================
    switch_top #(
        .N(N),
        .PD_WIDTH(PD_WIDTH),
        .DEPTH_LOG(DEPTH_LOG),
        .N_16_WIDTH(N_16_WIDTH),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(K)
    ) uut (
        .clk_sys(clk_sys),
        .clk_mem(clk_mem),
        .rst_n(rst_n),
        .we_in(we_in),
        
        // Manually connect the explicit ports
        .eg_port_in_0(eg_port_0),   .eg_port_in_1(eg_port_1),
        .eg_port_in_2(eg_port_2),   .eg_port_in_3(eg_port_3),
        .eg_port_in_4(eg_port_4),   .eg_port_in_5(eg_port_5),
        .eg_port_in_6(eg_port_6),   .eg_port_in_7(eg_port_7),
        .eg_port_in_8(eg_port_8),   .eg_port_in_9(eg_port_9),
        .eg_port_in_10(eg_port_10), .eg_port_in_11(eg_port_11),
        .eg_port_in_12(eg_port_12), .eg_port_in_13(eg_port_13),
        .eg_port_in_14(eg_port_14), .eg_port_in_15(eg_port_15),

        .egress_port_0(egress_port_0),   .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),   .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),   .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),   .egress_port_7(egress_port_7),
        .egress_port_8(egress_port_8),   .egress_port_9(egress_port_9),
        .egress_port_10(egress_port_10), .egress_port_11(egress_port_11),
        .egress_port_12(egress_port_12), .egress_port_13(egress_port_13),
        .egress_port_14(egress_port_14), .egress_port_15(egress_port_15),
        .current_bank_sel(current_bank_sel)
    );

    // =========================================================================
    // 4. CLOCK GENERATION
    // =========================================================================
    // 100 MHz System Clock
    initial begin
        clk_sys = 0;
        forever #80 clk_sys = ~clk_sys; 
    end

    // 100 MHz Memory Clock (Synchronized for this test)
    initial begin
        clk_mem = 0;
        forever #5 clk_mem = ~clk_mem; 
    end

    // =========================================================================
    // 5. STIMULUS (Incast Scenario)
    // =========================================================================
    initial begin
        // --- Initialize ---
        rst_n = 0;
        we_in = 0;
        
        // Default all destinations to Port 15 (just to be safe/idle)
        eg_port_0 = 15; eg_port_1 = 15; eg_port_2 = 15; eg_port_3 = 15;
        eg_port_4 = 15; eg_port_5 = 15; eg_port_6 = 15; eg_port_7 = 15;
        eg_port_8 = 15; eg_port_9 = 15; eg_port_10 = 15; eg_port_11 = 15;
        eg_port_12 = 15; eg_port_13 = 15; eg_port_14 = 15; eg_port_15 = 15;

        $display("Time: %0t | Simulation Started", $time);

        // --- Reset Phase ---
        #100;
        rst_n = 1;
        #100;
 
        // --- Configure INCAST (5 Ports -> Port 0) ---
        // We set inputs 0, 1, 2, 3, 4 to point to Destination 0
        eg_port_0 = 0;
        eg_port_1 = 0;
        eg_port_2 = 0;
        eg_port_3 = 0;
        eg_port_4 = 0;

        $display("Time: %0t | Configuring Incast: Inputs 0-4 -> Output 0", $time);

        // --- Start Stress Test ---
        // Assert Write Enable for the first 5 ports
        // 16'h001F = Binary 0000_0000_0001_1111
        we_in = 16'h001F; 

        // Run long enough to overflow Queue 0
        // Queue Depth = 1024
        // TDM services 5 requests every 16 cycles.
        // 1024 * (16/5) = ~3300 cycles.
        // We run for 6000 cycles to ensure we see dropping behavior.
        
        repeat (100) @(posedge clk_mem);

        // --- Stop Traffic ---
        $display("Time: %0t | Stopping Traffic (Buffer should be full/dropping)", $time);
        we_in = 0;

        // --- Allow Drain Time ---
        repeat (100) @(posedge clk_mem);

        $display("Time: %0t | Test Complete", $time);
        $finish;
    end

    // =========================================================================
    // 6. HELPER: Signal Spy (For Waveform Debugging)
    // =========================================================================
    // Since we are inside the testbench, we can assign internal signals to 
    // variables here for easier finding in the Vivado Waveform viewer.
    
    // Look at Queue 0 Length (Target of Incast)
    wire [DEPTH_LOG:0] debug_q0_len;
    // Note: This relies on the naming convention inside the generate block in switch_top.
    // In switch_top: obm_inst[0].u_queue.current_len
    assign debug_q0_len = uut.obm_inst[0].u_queue.current_len;

    // Look at the "Dropped" signal for Queue 0 (from the WAC)
    wire debug_wac_drop_0;
    assign debug_wac_drop_0 = uut.u_wac.drop_bit_gen[0];

    // Look at Global Shared Pool
    wire [15:0] debug_pool_left;
    assign debug_pool_left = uut.s_p.shared_pool_left;

    initial begin
        // Monitor print every 1000 cycles to track progress in Tcl Console
        forever begin
            #10000; // 1000 cycles * 10ns
            $display("Time: %0t | Q0 Length: %d | Pool Left: %d", 
                     $time, debug_q0_len, debug_pool_left);
        end
    end

endmodule