`timescale 1ns / 1ps

module tb_2_switch_top;

    // =========================================================================
    // 1. PARAMETERS (Must match switch_top)
    // =========================================================================
    parameter N = 16;
    parameter PD_WIDTH = 11;
    parameter DEPTH_LOG = 11; // Changed from 10 to 7
    parameter N_16_WIDTH = 11;
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 7); // Changed shift from 10 to 7;
    parameter K = 8;

    // =========================================================================
    // 2. SIGNALS
    // =========================================================================
    reg clk_sys;
    reg clk_mem;
    reg rst_n;
    reg [N-1:0] we_in;

    // Individual Destination Port Signals
    reg [3:0] eg_port_0,  eg_port_1,  eg_port_2,  eg_port_3;
    reg [3:0] eg_port_4,  eg_port_5,  eg_port_6,  eg_port_7;
    reg [3:0] eg_port_8,  eg_port_9,  eg_port_10, eg_port_11;
    reg [3:0] eg_port_12, eg_port_13, eg_port_14, eg_port_15;

    // Outputs (16 separate ports)
    wire [15:0] egress_port_0;
    wire [15:0] egress_port_1;
    wire [15:0] egress_port_2;
    wire [15:0] egress_port_3;
    wire [15:0] egress_port_4;
    wire [15:0] egress_port_5;
    wire [15:0] egress_port_6;
    wire [15:0] egress_port_7;
    wire [15:0] egress_port_8;
    wire [15:0] egress_port_9;
    wire [15:0] egress_port_10;
    wire [15:0] egress_port_11;
    wire [15:0] egress_port_12;
    wire [15:0] egress_port_13;
    wire [15:0] egress_port_14;
    wire [15:0] egress_port_15;

    // Debug output
    wire [N-1:0] obm_we_a_debug;

    // =========================================================================
    // 3. DUT INSTANTIATION
    // =========================================================================
    switch_top #(
        .N(N),
        .PD_WIDTH(PD_WIDTH),
        .DEPTH_LOG(DEPTH_LOG),
        .N_16_WIDTH(N_16_WIDTH),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(K)
    ) uut (
        .clk_sys(clk_sys),
        .clk_mem(clk_mem),
        .rst_n(rst_n),
        .we_in(we_in),
        
        // Manually connect the explicit inputs
        .eg_port_in_0(eg_port_0),   .eg_port_in_1(eg_port_1),
        .eg_port_in_2(eg_port_2),   .eg_port_in_3(eg_port_3),
        .eg_port_in_4(eg_port_4),   .eg_port_in_5(eg_port_5),
        .eg_port_in_6(eg_port_6),   .eg_port_in_7(eg_port_7),
        .eg_port_in_8(eg_port_8),   .eg_port_in_9(eg_port_9),
        .eg_port_in_10(eg_port_10), .eg_port_in_11(eg_port_11),
        .eg_port_in_12(eg_port_12), .eg_port_in_13(eg_port_13),
        .eg_port_in_14(eg_port_14), .eg_port_in_15(eg_port_15),

        // Connect the 16 separate output ports
        .egress_port_0(egress_port_0),   .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),   .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),   .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),   .egress_port_7(egress_port_7),
        .egress_port_8(egress_port_8),   .egress_port_9(egress_port_9),
        .egress_port_10(egress_port_10), .egress_port_11(egress_port_11),
        .egress_port_12(egress_port_12), .egress_port_13(egress_port_13),
        .egress_port_14(egress_port_14), .egress_port_15(egress_port_15)
    );

    // =========================================================================
    // 4. CLOCK GENERATION
    // =========================================================================
    // 100 MHz System Clock
    initial begin
        clk_sys = 0;
        #65
        clk_sys = ~clk_sys;
        forever #80 clk_sys = ~clk_sys; 
    end

    // 100 MHz Memory Clock
    initial begin
        clk_mem = 0;
        forever #5 clk_mem = ~clk_mem; 
    end

    // =========================================================================
    // 5. STIMULUS (Dual Incast Scenario)
    // =========================================================================
    initial begin
        // --- Initialize ---
        rst_n = 0;
        we_in = 0;
        
        // Default all destinations to Port 15 (safe default)
        eg_port_0 = 15; eg_port_1 = 15; eg_port_2 = 15; eg_port_3 = 15;
        eg_port_4 = 15; eg_port_5 = 15; eg_port_6 = 15; eg_port_7 = 15;
        eg_port_8 = 15; eg_port_9 = 15; eg_port_10 = 15; eg_port_11 = 15;
        eg_port_12 = 15; eg_port_13 = 15; eg_port_14 = 15; eg_port_15 = 15;

        $display("Time: %0t | Simulation Started", $time);

        // --- Reset Phase ---
        #75;
        rst_n = 1;
        #235;
 
        // --- Configure SCENARIO ---
        // Group 1: Inputs 0, 1, 2, 3, 4 -> Destination 0
        eg_port_0 = 0; eg_port_1 = 0; eg_port_2 = 0; eg_port_3 = 0; eg_port_4 = 0;

        // Group 2: Inputs 5, 6, 7, 8, 9 -> Destination 15
        eg_port_5 = 15; eg_port_6 = 15; eg_port_7 = 15; eg_port_8 = 15; eg_port_9 = 15;

        $display("Time: %0t | Configuring: Inputs 0-4 -> Port 0 AND Inputs 5-9 -> Port 15", $time);

        // --- Start Traffic ---
        // Enable Write for Ports 0 through 9 (10 ports total)
        // Binary: 0000_0011_1111_1111 = Hex: 0x03FF
        we_in = 16'h03FF; 

        // Run for 100 cycles as requested
        repeat (10000) @(posedge clk_mem);

        // --- Stop Traffic ---
        $display("Time: %0t | Stopping Traffic", $time);
        we_in = 0;

        // --- Allow Drain Time ---
        repeat (10000) @(posedge clk_mem);

        $display("Time: %0t | Test Complete", $time);
        $finish;
    end

    // =========================================================================
    // 6. HELPER: Signal Spy (For Waveform Debugging)
    // =========================================================================
    
    // Debug Queue 0 (Destination for first group)
    wire [DEPTH_LOG:0] debug_q0_len;
    assign debug_q0_len = uut.obm_inst[0].u_queue.current_len;

    // Debug Queue 15 (Destination for second group)
    wire [DEPTH_LOG:0] debug_q15_len;
    assign debug_q15_len = uut.obm_inst[15].u_queue.current_len;

    // Look at Global Shared Pool
    wire signed [15:0] debug_pool_left; // Make sure this matches your pool manager output
    assign debug_pool_left = uut.s_p.shared_pool_left;

    initial begin
        // Monitor print
        forever begin
            #10000; 
            $display("Time: %0t | Q0 Len: %d | Q15 Len: %d | Pool Left: %d", 
                     $time, debug_q0_len, debug_q15_len, debug_pool_left);
        end
    end

endmodule