`timescale 1ns / 1ps

module tb_uniform;

    // =========================================================================
    // 1. PARAMETERS (Must match switch_top)
    // =========================================================================
    parameter N = 16;
    parameter PD_WIDTH = 11;
    parameter DEPTH_LOG = 11; 
    parameter N_16_WIDTH = 11;
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 7); 
    parameter K = 8;

    // =========================================================================
    // 2. SIGNALS
    // =========================================================================
    reg clk_sys;
    reg clk_mem;
    reg rst_n;
    reg [N-1:0] we_in;

    // Individual Destination Port Signals
    reg [3:0] eg_port_0,  eg_port_1,  eg_port_2,  eg_port_3;
    reg [3:0] eg_port_4,  eg_port_5,  eg_port_6,  eg_port_7;
    reg [3:0] eg_port_8,  eg_port_9,  eg_port_10, eg_port_11;
    reg [3:0] eg_port_12, eg_port_13, eg_port_14, eg_port_15;

    // Outputs
    wire [15:0] egress_port_0;
    wire [15:0] egress_port_1;
    wire [15:0] egress_port_2;
    wire [15:0] egress_port_3;
    wire [15:0] egress_port_4;
    wire [15:0] egress_port_5;
    wire [15:0] egress_port_6;
    wire [15:0] egress_port_7;
    wire [15:0] egress_port_8;
    wire [15:0] egress_port_9;
    wire [15:0] egress_port_10;
    wire [15:0] egress_port_11;
    wire [15:0] egress_port_12;
    wire [15:0] egress_port_13;
    wire [15:0] egress_port_14;
    wire [15:0] egress_port_15;

    // =========================================================================
    // 3. DUT INSTANTIATION
    // =========================================================================
    switch_top #(
        .N(N),
        .PD_WIDTH(PD_WIDTH),
        .DEPTH_LOG(DEPTH_LOG),
        .N_16_WIDTH(N_16_WIDTH),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(K)
    ) uut (
        .clk_sys(clk_sys),
        .clk_mem(clk_mem),
        .rst_n(rst_n),
        .we_in(we_in),
        
        .eg_port_in_0(eg_port_0),   .eg_port_in_1(eg_port_1),
        .eg_port_in_2(eg_port_2),   .eg_port_in_3(eg_port_3),
        .eg_port_in_4(eg_port_4),   .eg_port_in_5(eg_port_5),
        .eg_port_in_6(eg_port_6),   .eg_port_in_7(eg_port_7),
        .eg_port_in_8(eg_port_8),   .eg_port_in_9(eg_port_9),
        .eg_port_in_10(eg_port_10), .eg_port_in_11(eg_port_11),
        .eg_port_in_12(eg_port_12), .eg_port_in_13(eg_port_13),
        .eg_port_in_14(eg_port_14), .eg_port_in_15(eg_port_15),

        .egress_port_0(egress_port_0),   .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),   .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),   .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),   .egress_port_7(egress_port_7),
        .egress_port_8(egress_port_8),   .egress_port_9(egress_port_9),
        .egress_port_10(egress_port_10), .egress_port_11(egress_port_11),
        .egress_port_12(egress_port_12), .egress_port_13(egress_port_13),
        .egress_port_14(egress_port_14), .egress_port_15(egress_port_15)
    );

    // =========================================================================
    // 4. CLOCK GENERATION
    // =========================================================================
    initial begin
        clk_sys = 0;
        #65
        clk_sys = ~clk_sys;
        forever #80 clk_sys = ~clk_sys; 
    end

    initial begin
        clk_mem = 0;
        forever #5 clk_mem = ~clk_mem; 
    end

    // =========================================================================
    // 5. STIMULUS
    // =========================================================================
    integer i;
    integer t;
    real total_packets_served;
    real throughput;
    real normalization_factor;
    real packet_size;
    real sys_clk_period;
    real bandwidth;
    real start_time;
    real end_time;
    real scaled_clk;
    real sim_time;
    real total_clks;
    // --- STATISTICS VARIABLES (Moved to TOP of initial block) ---
    initial begin
        // Declarations must be here!
        
        

        //Simulation outputs
        total_packets_served = 0;
        throughput = 0;
        
        //User Defined
        packet_size = 1500*8; //in bits;
        sys_clk_period = 160;
        bandwidth = 100;//in Gbps
        start_time = 555;//in ns
        end_time = 628000;//in ns
        
        //Derived attributes
        scaled_clk = packet_size/bandwidth;//in ns
        sim_time = end_time - start_time; // USER DEFINED
        total_clks = sim_time/sys_clk_period;
       
        // --- Initialize Inputs ---
        rst_n = 0;
        we_in = 0;
        
        // Default safe ports
        eg_port_0 = 15; eg_port_1 = 15; eg_port_2 = 15; eg_port_3 = 15;
        eg_port_4 = 15; eg_port_5 = 15; eg_port_6 = 15; eg_port_7 = 15;
        eg_port_8 = 15; eg_port_9 = 15; eg_port_10 = 15; eg_port_11 = 15;
        eg_port_12 = 15; eg_port_13 = 15; eg_port_14 = 15; eg_port_15 = 15;

        $display("Time: %0t | Simulation Started", $time);

        // --- Reset Phase ---
        #75;
        rst_n = 1;
        #235;

        // ---------------------------------------------------------------------
        // PHASE 1: Fill Buffer
        // ---------------------------------------------------------------------
        $display("Time: %0t | Starting Phase 1: Filling Buffer (Port 0 & 1 -> Dest 0)", $time);
        
        for (i = 0; i < 2000; i = i + 1) begin
            @(posedge clk_sys);
            #1;
            we_in = 16'b0000_0000_0000_0011; // Enable Port 0 & 1
            eg_port_0 = 4'd0;
            eg_port_1 = 4'd0;
        end

        // ---------------------------------------------------------------------
        // PHASE 2: Distributed Incast
        // ---------------------------------------------------------------------
        $display("Time: %0t | Starting Phase 2: Distributed 2-to-1 Incast", $time);

        for (i = 0; i < 1000; i = i + 1) begin
            @(posedge clk_sys);
            #1;
            we_in = 16'hFFFF; // All 16 ports active

            eg_port_0  = 4'd1; eg_port_1  = 4'd1;
            eg_port_2  = 4'd2; eg_port_3  = 4'd2;
            eg_port_4  = 4'd3; eg_port_5  = 4'd3;
            eg_port_6  = 4'd4; eg_port_7  = 4'd4;
            eg_port_8  = 4'd5; eg_port_9  = 4'd5;
            eg_port_10 = 4'd6; eg_port_11 = 4'd6;
            eg_port_12 = 4'd7; eg_port_13 = 4'd7;
            eg_port_14 = 4'd8; eg_port_15 = 4'd8;
        end

        // ---------------------------------------------------------------------
        // PHASE 3: Drain
        // ---------------------------------------------------------------------
        $display("Time: %0t | Starting Phase 3: Draining Queues", $time);
        
        we_in = 16'h0000; // Stop inputs
        
        repeat (2500) begin
            @(posedge clk_sys);
        end

        #500;
        
        // ---------------------------------------------------------------------
        // PHASE 4: Throughput Calculation
        // ---------------------------------------------------------------------
        // Sum up the counters from the DUT
        for (t = 0; t < 16; t = t + 1) begin
            // FIX: Using 'uut' because that is your instance name above
            total_packets_served = total_packets_served + uut.egress_pkt_count[t];
        end
    
        throughput = total_packets_served*packet_size/(total_clks*scaled_clk);
    
        $display("----------------------------------------------------------------");
        $display("Time: %0t | Simulation Finished", $time);
        $display("----------------------------------------------------------------");
        $display("Total Packets Served : %0d", total_packets_served);
        $display("Normalization Factor : %0f", normalization_factor);
        $display("Final Throughput     : %0f Gbps", throughput);
        $display("----------------------------------------------------------------");
    
        $finish;
    end
endmodule