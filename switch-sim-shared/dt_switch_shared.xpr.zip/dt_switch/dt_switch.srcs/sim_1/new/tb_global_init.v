`timescale 1ns / 1ps

module tb_global_init;

    // =========================================================================
    // 1. CONFIGURATION PARAMETERS (User Tunable)
    // =========================================================================
    // 0 = Uniform, 1 = Zipf, 2 = Skewed
    parameter DISTRIBUTION_TYPE = 2; 
    
    // Burst % of buffer size for Phase 2
    parameter BURST_PERCENT     = 30; 
    parameter DEPTH_LOG         = 11;
    parameter N                 = 16;
    parameter TOTAL_MEM_CAPACITY = 2048; 

    // File logging
    integer f;
    initial begin
        f = $fopen("VERILOG_RESULTS.txt", "a"); 
    end
    
    // Quotas
    localparam PHASE_1_CYCLES = (TOTAL_MEM_CAPACITY * 18) / 10; 
    localparam PHASE_2_QUOTA  = (TOTAL_MEM_CAPACITY * BURST_PERCENT) / 100;

    // =========================================================================
    // 2. SIGNALS
    // =========================================================================
    reg clk_sys;
    reg clk_mem;
    reg rst_n;
    reg [N-1:0] we_in;
    reg [3:0] eg_port_in [0:15]; 
    wire [15:0] egress_ports [0:15];

    // Stats Signals
    reg [31:0] current_total_occupancy;
    reg [31:0] max_total_occupancy = 0;
    
    // Tracking Last Packet
    real last_packet_time;
    real packet_counter;
    integer pkt_i;

    // =========================================================================
    // 3. DUT INSTANTIATION
    // =========================================================================
    switch_top #(
        .N(N),
        .PD_WIDTH(11),
        .DEPTH_LOG(11),
        .N_16_WIDTH(11),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(8)
    ) uut (
        .clk_sys(clk_sys),
        .clk_mem(clk_mem),
        .rst_n(rst_n),
        .we_in(we_in),
        .eg_port_in_0(eg_port_in[0]),   .eg_port_in_1(eg_port_in[1]),
        .eg_port_in_2(eg_port_in[2]),   .eg_port_in_3(eg_port_in[3]),
        .eg_port_in_4(eg_port_in[4]),   .eg_port_in_5(eg_port_in[5]),
        .eg_port_in_6(eg_port_in[6]),   .eg_port_in_7(eg_port_in[7]),
        .eg_port_in_8(eg_port_in[8]),   .eg_port_in_9(eg_port_in[9]),
        .eg_port_in_10(eg_port_in[10]), .eg_port_in_11(eg_port_in[11]),
        .eg_port_in_12(eg_port_in[12]), .eg_port_in_13(eg_port_in[13]),
        .eg_port_in_14(eg_port_in[14]), .eg_port_in_15(eg_port_in[15]),
        .egress_port_0(egress_ports[0]),   .egress_port_1(egress_ports[1]),
        .egress_port_2(egress_ports[2]),   .egress_port_3(egress_ports[3]),
        .egress_port_4(egress_ports[4]),   .egress_port_5(egress_ports[5]),
        .egress_port_6(egress_ports[6]),   .egress_port_7(egress_ports[7]),
        .egress_port_8(egress_ports[8]),   .egress_port_9(egress_ports[9]),
        .egress_port_10(egress_ports[10]), .egress_port_11(egress_ports[11]),
        .egress_port_12(egress_ports[12]), .egress_port_13(egress_ports[13]),
        .egress_port_14(egress_ports[14]), .egress_port_15(egress_ports[15])
    );

    // =========================================================================
    // 4. CLOCK & MONITOR
    // =========================================================================
    initial begin
        clk_sys = 0;
        #65;
        forever #80 clk_sys = ~clk_sys; 
    end

    initial begin
        clk_mem = 0;
        forever #5 clk_mem = ~clk_mem; 
    end

    // --- CONTINUOUS MONITOR: Count Packets & Update Time ---
    initial begin
        packet_counter = 0;
        last_packet_time = 0;
    end

    always @(posedge clk_sys) begin
        if (rst_n) begin
            // 1. Calculate Occupancy (High Score)
            current_total_occupancy = 0;
            for (pkt_i = 0; pkt_i < N; pkt_i = pkt_i + 1) begin
                current_total_occupancy = current_total_occupancy + uut.q_len_flat[pkt_i*DEPTH_LOG +: DEPTH_LOG];
            end
            if (current_total_occupancy > max_total_occupancy) max_total_occupancy = current_total_occupancy;

            // 2. Track Packets & Update Timestamp
            for (pkt_i = 0; pkt_i < 16; pkt_i = pkt_i + 1) begin
                if (egress_ports[pkt_i] != 0) begin
                    packet_counter = packet_counter + 1;
                    last_packet_time = $time; // <--- UPDATE END TIME DYNAMICALLY
                end
            end
        end
    end

    // =========================================================================
    // 5. STIMULUS
    // =========================================================================
    integer i, p;
    integer active_phase2;
    reg [3:0] dist_map [0:15];      
    integer pkts_sent_count [0:15]; 

    // Statistics
    real throughput;
    real normalization_factor;
    real packet_size;
    real sys_clk_period;
    real bandwidth;
    real start_time;
    real scaled_clk;
    real sim_time;
    real total_clks;
    reg [3:0] dest;

    initial begin
        // Init Stats
        normalization_factor = 1.0;
        packet_size = 1500 * 8; 
        sys_clk_period = 160;   
        bandwidth = 100;        
        scaled_clk = packet_size / bandwidth; 
        
        // Init Signals
        rst_n = 0;
        we_in = 0;
        for (p=0; p<16; p=p+1) eg_port_in[p] = 15; 

        // Setup Distribution
        case (DISTRIBUTION_TYPE)
            0: begin // UNIFORM
                dist_map[0]=1; dist_map[1]=1; dist_map[2]=2; dist_map[3]=2;
                dist_map[4]=3; dist_map[5]=3; dist_map[6]=4; dist_map[7]=4;
                dist_map[8]=5; dist_map[9]=5; dist_map[10]=6; dist_map[11]=6;
                dist_map[12]=7; dist_map[13]=7; dist_map[14]=8; dist_map[15]=8;
            end
            1: begin // ZIPF
                dist_map[0]=6; dist_map[1]=6; dist_map[2]=6; dist_map[3]=6;
                dist_map[4]=6; dist_map[5]=6; dist_map[6]=6; dist_map[7]=5;
                dist_map[8]=5; dist_map[9]=5; dist_map[10]=5; dist_map[11]=3;
                dist_map[12]=3; dist_map[13]=3; dist_map[14]=2; dist_map[15]=2;
            end
            2: begin // SKEWED
                dist_map[0]=7; dist_map[1]=7; dist_map[2]=7; dist_map[3]=7;
                dist_map[4]=7; dist_map[5]=7; dist_map[6]=7; dist_map[7]=7;
                dist_map[8]=7; dist_map[9]=4; dist_map[10]=4; dist_map[11]=6;
                dist_map[12]=6; dist_map[13]=6; dist_map[14]=2; dist_map[15]=2;
            end
        endcase

        // Reset
        $display("Time: %0t | Simulation Started", $time);
        #75; rst_n = 1; #235;
        start_time = $time;

        // --- PHASE A: Fill Buffer ---
        $display("Time: %0t | Starting Phase A: Filling Buffer", $time);
        for (i = 0; i < PHASE_1_CYCLES; i = i + 1) begin
            @(posedge clk_sys); #1;
            we_in = 16'b0000_0000_0000_0011; 
            eg_port_in[0] = 4'd0; eg_port_in[1] = 4'd0;           
        end

        // --- PHASE B: Workload ---
        $display("Time: %0t | Starting Phase B: Workload Generation", $time);
        for (p=0; p<16; p=p+1) pkts_sent_count[p] = 0;
        active_phase2 = 1; 
        
        while (active_phase2 > 0) begin
            @(posedge clk_sys); #1;
            active_phase2 = 0; 
            we_in = 16'h0000;  

            for (p = 0; p < 16; p = p + 1) begin
                dest = dist_map[p]; 
                if (pkts_sent_count[dest] < PHASE_2_QUOTA) begin
                    we_in[p] = 1'b1;
                    eg_port_in[p] = dest;
                    pkts_sent_count[dest] = pkts_sent_count[dest] + 1;
                    active_phase2 = active_phase2 + 1;
                end
            end
        end

        // --- PHASE 3: WAIT FOR TOTAL EMPTINESS ---
        $display("Time: %0t | Phase B Complete. Waiting for Switch to Empty...", $time);
        we_in = 16'h0000;
        
        // Wait until: 
        // 1. Buffer is empty (current_total_occupancy == 0)
        // 2. No writing is happening (we_in == 0)
        while (current_total_occupancy > 0 || we_in != 0) begin
            @(posedge clk_sys);
        end
        
        #500; // Small cooldown to safely capture the very last egress pulse

        // --- PHASE 4: CALCULATION ---
        
        // 1. Use the timestamp of the LAST actual packet sent
        sim_time = last_packet_time - start_time;
        total_clks = sim_time / sys_clk_period;

        // 2. Throughput
        if (total_clks > 0)
            throughput = (packet_counter * packet_size) / (total_clks * scaled_clk);
        else
            throughput = 0;

        // Log Results
        $fdisplay(f, "RUN CONFIG: Dist=%0d Burst=%0d", DISTRIBUTION_TYPE, BURST_PERCENT);
        $fdisplay(f, "Final Throughput: %0f Gbps", throughput);
        $fdisplay(f, "--------------------------------");
        
        $display("----------------------------------------------------------------");
        $display("Time: %0t | Simulation Finished (Buffer Empty)", $time);
        $display("----------------------------------------------------------------");
        $display("Last Packet Time     : %0t ns", last_packet_time);
        $display("Total Packets Served : %0d", packet_counter);
        $display("Final Throughput     : %0f Gbps", throughput);
        $display("----------------------------------------------------------------");
        $display("Max Memory Occupancy : %0d packets (Capacity: %0d)", max_total_occupancy, TOTAL_MEM_CAPACITY);
        $display("----------------------------------------------------------------");
        
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Time: %0t | Simulation Finished", $time);
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Total Packets Served : %0d", packet_counter);
        $fdisplay(f,"Normalization Factor : %0f", normalization_factor);
        $fdisplay(f,"Final Throughput     : %0f Gbps", throughput);
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Max Memory Occupancy : %0d packets (Capacity: %0d)", max_total_occupancy, TOTAL_MEM_CAPACITY);
        $fdisplay(f,"----------------------------------------------------------------");
        
        $fclose(f);
        $finish;
    end

endmodule