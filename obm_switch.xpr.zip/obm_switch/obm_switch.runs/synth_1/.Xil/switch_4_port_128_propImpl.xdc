set_property SRC_FILE_INFO {cfile:/home/dan/Desktop/obm_switch/obm_switch.srcs/constrs_1/new/top_constraints.xdc rfile:../../../obm_switch.srcs/constrs_1/new/top_constraints.xdc id:1} [current_design]
set_property src_info {type:XDC file:1 line:13 export:INPUT save:INPUT read:READ} [current_design]
create_pblock pblock_switch_2
resize_pblock [get_pblocks pblock_switch_2] -add {SLICE_X0Y0:SLICE_X10Y10}
resize_pblock [get_pblocks pblock_switch_2] -add {RAMB18_X0Y0:RAMB18_X0Y5}
set_property src_info {type:XDC file:1 line:14 export:INPUT save:INPUT read:READ} [current_design]
add_cells_to_pblock [get_pblocks pblock_switch_2] [get_cells -quiet -hierarchical *u_switch_top*]
