onbreak {quit -f}
onerror {quit -f}

vsim -voptargs="+acc "  -gDISTRIBUTION_TYPE=2 -gBURST_PERCENT=50 -L xpm -L xil_defaultlib -L unisims_ver -L unimacro_ver -L secureip -lib xil_defaultlib xil_defaultlib.clk_wiz_2 xil_defaultlib.glbl

set NumericStdNoWarnings 1
set StdArithNoWarnings 1

do {wave.do}

view wave
view structure
view signals

do {clk_wiz_2.udo}

run 1000ns

quit -force
