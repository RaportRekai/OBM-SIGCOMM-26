-makelib xcelium_lib/xpm -sv \
  "/home/Xilinx/Vivado/2022.2/data/ip/xpm/xpm_cdc/hdl/xpm_cdc.sv" \
-endlib
-makelib xcelium_lib/xpm \
  "/home/Xilinx/Vivado/2022.2/data/ip/xpm/xpm_VCOMP.vhd" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  "../../../../obm_switch.gen/sources_1/ip/clk_wiz_2/clk_wiz_2_clk_wiz.v" \
  "../../../../obm_switch.gen/sources_1/ip/clk_wiz_2/clk_wiz_2.v" \
-endlib
-makelib xcelium_lib/xil_defaultlib \
  glbl.v
-endlib

