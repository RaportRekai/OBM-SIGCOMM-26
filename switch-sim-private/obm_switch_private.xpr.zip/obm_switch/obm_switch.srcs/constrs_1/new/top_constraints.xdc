# 400 MHz direct design clock
create_clock -period 2.500 -name clk_mem -waveform {0.000 1.250} [get_ports clk_mem]
# 200 MHz direct design clock
#create_clock -period 5.000 -name clk_mem -waveform {0.000 2.500} [get_ports clk_mem]

# 100 MHz direct design clock
#create_clock -period 10.000 -name clk_mem -waveform {0.000 5.000} [get_ports clk_mem]

# 50 MHz direct design clock
#create_clock -period 20.000 -name clk_mem -waveform {0.000 10.000} [get_ports clk_mem]

# Floorplanning
create_pblock pblock_switch_2
add_cells_to_pblock [get_pblocks pblock_switch_2] [get_cells -quiet -hierarchical *u_switch_top*]
resize_pblock [get_pblocks pblock_switch_2] -add {SLICE_X0Y0:SLICE_X10Y10 RAMB18_X0Y0:RAMB18_X0Y5}

# Ignore timing to dummy output
set_false_path -to [get_ports dummy_checksum]