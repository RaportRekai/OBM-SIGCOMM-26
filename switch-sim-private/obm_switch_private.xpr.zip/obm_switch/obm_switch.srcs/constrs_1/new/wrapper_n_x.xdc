# Physical 300 MHz differential input clock into Clocking Wizard
create_clock -period 3.333 -name sys_clk_pin -waveform {0.000 1.667} [get_ports clk_mem_p]

# Floorplanning
create_pblock pblock_switch_2
add_cells_to_pblock [get_pblocks pblock_switch_2] [get_cells -quiet -hierarchical *uut*]
#resize_pblock [get_pblocks pblock_switch_2] -add {SLICE_X0Y0:SLICE_X10Y10 RAMB18_X0Y0:RAMB18_X0Y5}