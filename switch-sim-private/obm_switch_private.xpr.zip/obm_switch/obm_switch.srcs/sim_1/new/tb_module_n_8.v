`timescale 1ns / 1ps

module tb_module_n_8;

    // ------------------------------------------------
    // 1. Parameters
    // ------------------------------------------------
    parameter N = 8;
    parameter LEVEL = $clog2(N); // 3
    parameter ADDRESS_WIDTH = 6;
    parameter WIDTH = 8;
    parameter LEN_WIDTH = 8;
    
    // Total size of the input memory bus
    parameter MEM_SIZE = N * ADDRESS_WIDTH * N; 

    // ------------------------------------------------
    // 2. Signals
    // ------------------------------------------------
    reg clk;
    reg rst_n;
    
    // Inputs
    reg [N-1:0] lqd_bit;            // Active User Bitmask
    reg [MEM_SIZE-1:0] mem_loc_in;  // Large Memory Pool
    
    // Queue Length Inputs
    reg [WIDTH-1:0] level_0 [0:N-1];

    // Outputs
    wire [LEVEL:0] out_3;           // Total active count
    
    wire [ADDRESS_WIDTH-1:0] mem_block_out [0:N-1]; // Array for easier checking
    
    wire [$clog2(N)-1:0] level_4_out;   // ID of winner
    wire [N-1:0] lqd_trigger;           // One-hot trigger
    wire [WIDTH-1+$clog2(N):0] level_3; // Max value + ID

    // ------------------------------------------------
    // 3. DUT Instantiation
    // ------------------------------------------------
    main_n_81 #(
        .N(N),
        .LEVEL(LEVEL),
        .ADDRESS_WIDTH(ADDRESS_WIDTH),
        .WIDTH(WIDTH),
        .LEN_WIDTH(LEN_WIDTH)
    ) dut (
        .clk(clk),
        .rst_n(rst_n),
        .lqd_bit(lqd_bit),
        .out_3(out_3),
        
        // Connect output wires to our array for loop checking
        .mem_block_1_1(mem_block_out[0]),
        .mem_block_1_2(mem_block_out[1]),
        .mem_block_1_3(mem_block_out[2]),
        .mem_block_1_4(mem_block_out[3]),
        .mem_block_1_5(mem_block_out[4]),
        .mem_block_1_6(mem_block_out[5]),
        .mem_block_1_7(mem_block_out[6]),
        .mem_block_1_8(mem_block_out[7]),

        .mem_loc_in(mem_loc_in),
        .level_4_out(level_4_out),
        .lqd_trigger(lqd_trigger),

        // Connect array elements to individual ports
        .level_0_0(level_0[0]),
        .level_0_1(level_0[1]),
        .level_0_2(level_0[2]),
        .level_0_3(level_0[3]),
        .level_0_4(level_0[4]),
        .level_0_5(level_0[5]),
        .level_0_6(level_0[6]),
        .level_0_7(level_0[7]),
        
        .level_3(level_3)
    );

    // ------------------------------------------------
    // 4. Clock Generation
    // ------------------------------------------------
    initial begin
        clk = 0;
        forever #5 clk = ~clk; // 10ns period
    end

    // ------------------------------------------------
    // 5. Test Procedures
    // ------------------------------------------------
    integer i;
    
    initial begin
        // --- Initialize ---
        rst_n = 0;
        lqd_bit = 0;
        mem_loc_in = 0;
        
        // Zero out queue lengths
        for (i = 0; i < N; i = i + 1) level_0[i] = 0;

        // --- Reset Sequence ---
        #20 rst_n = 1;
        #10;

        // ============================================================
        // TEST CASE 1: Single User & Comparator Check
        // ============================================================
        $display("\n--- Test Case 1: Single Port Active ---");
        lqd_bit = 8'b0000_1000; // Port 3 is active
        level_0[3] = 8'd50;     // Port 3 has load 50
        
        // Wait for pipeline latency (approx 3-4 clocks)
        repeat(5) @(posedge clk);
        
        if (out_3 == 1) $display("PASS: Adder Count is 1");
        else $display("FAIL: Adder Count is %d (Exp: 1)", out_3);

        if (level_4_out == 3) $display("PASS: Max Load ID is 3");
        else $display("FAIL: Max Load ID is %d (Exp: 3)", level_4_out);


        // ============================================================
        // TEST CASE 2: Multi-Port Memory Steering Logic
        // ============================================================
        // This is the critical test for your Demux/Shifter logic.
        $display("\n--- Test Case 2: Memory Steering (Packing Check) ---");
        
        // 1. Set Active Ports: 0, 2, 5, 7 (Pattern 10100101)
        // Total Active = 4
        lqd_bit = 8'b1010_0101; 
        
        // 2. Set Loads so Port 5 wins (this determines which memory bank is read)
        level_0[0] = 10;
        level_0[2] = 20;
        level_0[5] = 99; // WINNER
        level_0[7] = 5;
        
        // 3. Prepare Memory Input
        // Your logic selects a specific chunk of 'mem_loc_in' based on the Winner ID.
        // Winner = 5. So the module reads the 5th "Super Block" of input memory.
        // A "Super Block" is N * ADDRESS_WIDTH bits wide (8 * 6 = 48 bits).
        // 
        // We will populate this 5th Super Block with identifiable values:
        // Slot 0 (Should go to 1st active user -> Port 0) = 0x0A
        // Slot 1 (Should go to 2nd active user -> Port 2) = 0x0B
        // Slot 2 (Should go to 3rd active user -> Port 5) = 0x0C
        // Slot 3 (Should go to 4th active user -> Port 7) = 0x0D
        
        mem_loc_in = 0; // Clear
        
        // Calculate bit offset for Winner 5's bank: 5 * 48 = 240
        // Set the values inside that bank:
        mem_loc_in[240 +: 6] = 6'h0A; // First available block
        mem_loc_in[246 +: 6] = 6'h0B; // Second available block
        mem_loc_in[252 +: 6] = 6'h0C; // Third available block
        mem_loc_in[258 +: 6] = 6'h0D; // Fourth available block

        repeat(5) @(posedge clk);
        
        // --- Verification ---
        
        // A. Verify Winner
        if (level_4_out == 5) $display("PASS: Winner is Port 5");
        else $display("FAIL: Winner is %d (Exp: 5)", level_4_out);
        
        // B. Verify Active Count
        if (out_3 == 4) $display("PASS: Active Count is 4");
        else $display("FAIL: Active Count is %d (Exp: 4)", out_3);

        // C. Verify Memory Steering (The Hard Part)
        // The Demux tree should have routed the blocks from Bank 5 to the active ports *only*.
        $display("Checking Memory Routing...");
        
        if (mem_block_out[0] == 6'h0A) $display("PASS: Port 0 (Active 1) got Block 0x0A");
        else $display("FAIL: Port 0 got %h (Exp: 0x0A)", mem_block_out[0]);

        if (mem_block_out[2] == 6'h0B) $display("PASS: Port 2 (Active 2) got Block 0x0B");
        else $display("FAIL: Port 2 got %h (Exp: 0x0B)", mem_block_out[2]);
        
        if (mem_block_out[5] == 6'h0C) $display("PASS: Port 5 (Active 3) got Block 0x0C");
        else $display("FAIL: Port 5 got %h (Exp: 0x0C)", mem_block_out[5]);
        
        if (mem_block_out[7] == 6'h0D) $display("PASS: Port 7 (Active 4) got Block 0x0D");
        else $display("FAIL: Port 7 got %h (Exp: 0x0D)", mem_block_out[7]);

        // Verify inactive ports are cleared
        if (mem_block_out[1] == 0) $display("PASS: Port 1 (Inactive) is 0");
        else $display("FAIL: Port 1 got %h", mem_block_out[1]);

        $stop;
    end

endmodule