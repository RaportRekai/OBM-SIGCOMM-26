`timescale 1ns / 1ps

module tb_switch_8_port;

    // =========================================================================
    // 1. CONFIGURATION PARAMETERS
    // =========================================================================
    // 0 = Uniform, 1 = Zipf, 2 = Skewed
    parameter DISTRIBUTION_TYPE = 0; 

    
    // Burst % of buffer size for Phase 2
    reg [4:0]active_ports;
    parameter BURST_PERCENT     = 20; 
    parameter DEPTH_LOG         = 11;
    parameter N                 = 8;
    parameter TOTAL_MEM_CAPACITY = 1398; 

    // File logging
    integer f;
    initial begin
        f = $fopen("VERILOG_RESULTS.txt", "a"); 
    end
    
    // Quotas
    localparam PHASE_1_CYCLES = (TOTAL_MEM_CAPACITY * 4) / 5; 
    localparam PHASE_2_QUOTA  = (TOTAL_MEM_CAPACITY * BURST_PERCENT) / 100;

    // =========================================================================
    // 2. SIGNALS
    // =========================================================================
    reg clk_sys;
    reg clk_mem;
    reg rst_n;
    reg [N-1:0] we_in;
    reg [$clog2(N)-1:0] eg_port_in [0:N-1]; 
    wire [15:0] egress_ports [0:N-1];

    // Stats Signals
    reg [31:0] current_total_occupancy;
    reg [31:0] max_total_occupancy = 0;
    
    // Tracking Last Packet
    real last_packet_time;
    real packet_counter;
    integer pkt_i;

    // =========================================================================
    // 3. DUT INSTANTIATION
    // =========================================================================
    switch_8_port #(
        .N(N),
        .PD_WIDTH(11),
        .DEPTH_LOG(11),
        .N_16_WIDTH(11),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(6)
    ) uut (
        .clk_mem(clk_mem),
        .rst_n(rst_n),
        .we_in(we_in),
        .clk_sys(clk_sys),
        .eg_port_in_0(eg_port_in[0]),   .eg_port_in_1(eg_port_in[1]),
        .eg_port_in_2(eg_port_in[2]),   .eg_port_in_3(eg_port_in[3]),
        .eg_port_in_4(eg_port_in[4]),   .eg_port_in_5(eg_port_in[5]),
        .eg_port_in_6(eg_port_in[6]),   .eg_port_in_7(eg_port_in[7]),
       
        .egress_port_0(egress_ports[0]), .egress_port_1(egress_ports[1]),
        .egress_port_2(egress_ports[2]), .egress_port_3(egress_ports[3]),
        .egress_port_4(egress_ports[4]), .egress_port_5(egress_ports[5]),
        .egress_port_6(egress_ports[6]), .egress_port_7(egress_ports[7])
        
    );

    // =========================================================================
    // 4. CLOCK & MONITOR
    // =========================================================================
    initial begin
        clk_sys = 0;
        #25;
        forever #40 clk_sys = ~clk_sys; 
    end

    initial begin
        clk_mem = 0;
        forever #5 clk_mem = ~clk_mem; 
    end

    // --- CONTINUOUS MONITOR: Count Packets & Update Time ---
    initial begin
        packet_counter = 0;
        last_packet_time = 0;
    end

    always @(posedge clk_sys) begin
        if (rst_n) begin
            // 1. Calculate Occupancy (High Score)
            current_total_occupancy = 0;
            for (pkt_i = 0; pkt_i < N; pkt_i = pkt_i + 1) begin
                current_total_occupancy = current_total_occupancy + uut.q_len_flat[pkt_i*DEPTH_LOG +: DEPTH_LOG];
            end
            if (current_total_occupancy > max_total_occupancy) max_total_occupancy = current_total_occupancy;

            // 2. Track Packets & Update Timestamp
            for (pkt_i = 0; pkt_i < N; pkt_i = pkt_i + 1) begin
                if ((egress_ports[pkt_i] != 0) && (uut.q_len_flat[pkt_i*DEPTH_LOG +: DEPTH_LOG] > 0)) begin
                    packet_counter = packet_counter + 1;
                    last_packet_time = $time; 
                end
            end
        end
    end

    // =========================================================================
    // 5. STIMULUS
    // =========================================================================
    integer i, p;
    integer active_phase2;
    reg [$clog2(N)-1:0] dist_map [0:N-1];      
    integer pkts_sent_count [0:N-1]; 

    // Statistics
    real throughput;
    real normalization_factor;
    real packet_size;
    real sys_clk_period;
    real bandwidth;
    real start_time;
    real scaled_clk;
    real sim_time;
    real total_clks;
    reg [$clog2(N)-1:0] dest;

    initial begin
        // Init Stats
        normalization_factor = 1.0;
        packet_size = 1500 * 8; 
        sys_clk_period = 160;   
        bandwidth = 400;        
        scaled_clk = 30;//packet_size / bandwidth; 
        
        // Init Signals
        rst_n = 0;
        we_in = 0;
        for (p=0; p<N; p=p+1) eg_port_in[p] = N-1; 

        // Setup Distribution
        case (DISTRIBUTION_TYPE)
            0: begin // UNIFORM
                dist_map[0]=1; dist_map[1]=1; dist_map[2]=2; dist_map[3]=2;
                dist_map[4]=3; dist_map[5]=3; dist_map[6]=4; dist_map[7]=4;
                
            end
            1: begin // ZIPF
                dist_map[0]=1; dist_map[1]=1; dist_map[2]=1; dist_map[3]=1;
                dist_map[4]=2; dist_map[5]=2; dist_map[6]=3; dist_map[7]=3;
                
            end
            2: begin // SKEWED
                dist_map[0]=1; dist_map[1]=1; dist_map[2]=1; dist_map[3]=1;
                dist_map[4]=1; dist_map[5]=2; dist_map[6]=2; dist_map[7]=2;
                
            end
        endcase

        // Reset
        $display("Time: %0t | Simulation Started", $time);
        #75; rst_n = 1; #235;
        start_time = $time;

        // --- PHASE A: Fill Buffer ---
        $display("Time: %0t | Starting Phase A: Filling Buffer", $time);
        for (i = 0; i < PHASE_1_CYCLES; i = i + 1) begin
            @(posedge clk_sys); 
            we_in = 8'b0000_0011; 
            eg_port_in[0] = 3'd0; eg_port_in[1] = 3'd0;           
        end

        // --- PHASE B: Workload ---
        $display("Time: %0t | Starting Phase B: Workload Generation", $time);
        for (p=0; p<N; p=p+1) pkts_sent_count[p] = 0;
        active_phase2 = 1; 
        
        while (active_phase2 > 0) begin
            @(posedge clk_sys);
            active_phase2 = 0; 
            we_in = 8'h0000;  

            for (p = 0; p < N; p = p + 1) begin
                dest = dist_map[p]; 
                if (pkts_sent_count[dest] < PHASE_2_QUOTA) begin
                    we_in[p] = 1'b1;
                    eg_port_in[p] = dest;
                    pkts_sent_count[dest] = pkts_sent_count[dest] + 1;
                    active_phase2 = active_phase2 + 1;
                end
            end
        end

        // --- PHASE 3: WAIT FOR TOTAL EMPTINESS ---
        $display("Time: %0t | Phase B Complete. Waiting for Switch to Empty...", $time);
        we_in = 8'h0000;
        
        // Wait until: 
        // 1. Buffer is empty (current_total_occupancy == 0)
        // 2. No writing is happening (we_in == 0)
        // We add a small delay to ensure the 'last_packet_time' updates properly.
        while (current_total_occupancy > 0 || we_in != 0) begin
            @(posedge clk_sys);
        end
        
        #500; // Small cooldown to safely capture the very last egress pulse

        // --- PHASE 4: CALCULATION ---
        
        // 1. Use the timestamp of the LAST actual packet sent
        sim_time = last_packet_time - start_time;
        total_clks = sim_time / sys_clk_period;

        // 2. Throughput
        if (total_clks > 0)
            throughput = (packet_counter * packet_size) / (total_clks * scaled_clk);
        else
            throughput = 0;

        // Log Results
        $fdisplay(f, "RUN CONFIG: Dist=%0d Burst=%0d", DISTRIBUTION_TYPE, BURST_PERCENT);
        $fdisplay(f, "Final Throughput: %0f Gbps", throughput);
        $fdisplay(f, "--------------------------------");
        
        $display("----------------------------------------------------------------");
        $display("Time: %0t | Simulation Finished (Buffer Empty)", $time);
        $display("----------------------------------------------------------------");
        $display("Last Packet Time     : %0t ns", last_packet_time);
        $display("Total Packets Served : %0d", packet_counter);
        $display("Final Throughput     : %0f Gbps", throughput-(5.3*active_ports));
        $display("----------------------------------------------------------------");
        $display("Max Memory Occupancy : %0d packets (Capacity: %0d)", max_total_occupancy, TOTAL_MEM_CAPACITY);
        $display("----------------------------------------------------------------");
        
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Time: %0t | Simulation Finished", $time);
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Total Packets Served : %0d", packet_counter);
        $fdisplay(f,"Normalization Factor : %0f", normalization_factor);
        $fdisplay(f,"Final Throughput     : %0f Gbps", throughput-(5.3*active_ports));
        $fdisplay(f,"----------------------------------------------------------------");
        $fdisplay(f,"Max Memory Occupancy : %0d packets (Capacity: %0d)", max_total_occupancy, TOTAL_MEM_CAPACITY);
        $fdisplay(f,"----------------------------------------------------------------");
        
        $fclose(f);
        $finish;
    end

endmodule