module adder_1 #(
    parameter WIDTH = 1 // Default width, dynamically configurable
) (
    input clk,
    input [WIDTH-1:0] a, // Input A with dynamic width
    input [WIDTH-1:0] b, // Input B with dynamic width
    output reg [WIDTH:0] out // Output with WIDTH+1 to handle carry
);
    always @ (posedge clk)
    begin
        out <= a+b;
    end
endmodule
