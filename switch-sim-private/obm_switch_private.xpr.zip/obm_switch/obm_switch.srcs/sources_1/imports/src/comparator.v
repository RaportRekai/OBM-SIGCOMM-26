module comparator #(
    parameter WIDTH = 8, // Default width of the input values
    parameter N = 16,
    parameter LEVEL = $clog2(N)
) (
    input clk,                      // Clock signal
    input [WIDTH-1+LEVEL:0] a,            // Input value A
    input [WIDTH-1+LEVEL:0] b,            // Input value B
    output reg [WIDTH-1+LEVEL:0] greater  // Output: Greater value
);

    always @(posedge clk) begin
        if (a[WIDTH-1+LEVEL -: WIDTH] > b[WIDTH-1+LEVEL -: WIDTH])
            greater <= a;
        else
            greater <= b;
    end
    

endmodule


