
module main  #(
            parameter N = 16,  // Total number of input bits
            parameter LEVEL = $clog2(N), // Number of levels in the tree
            parameter ADDRESS_WIDTH = 6,
            parameter WIDTH = 8
            ) (
            
            input clk,
            input rst_n,
            input [N-1:0]lqd_bit,
            output [LEVEL:0]out_4,

            input [(N * ADDRESS_WIDTH*N) - 1 : 0] mem_loc_in,
            output wire [$clog2(N)-1:0]level_4_out,
            output wire [N-1:0] lqd_trigger,

            output [ADDRESS_WIDTH -1:0]mem_block_1_1,
            output [ADDRESS_WIDTH -1:0]mem_block_1_2,
            output [ADDRESS_WIDTH -1:0]mem_block_1_3,
            output [ADDRESS_WIDTH -1:0]mem_block_1_4,
            output [ADDRESS_WIDTH -1:0]mem_block_1_5,
            output [ADDRESS_WIDTH -1:0]mem_block_1_6,
            output [ADDRESS_WIDTH -1:0]mem_block_1_7,
            output [ADDRESS_WIDTH -1:0]mem_block_1_8,
            output [ADDRESS_WIDTH -1:0]mem_block_1_9,
            output [ADDRESS_WIDTH -1:0]mem_block_1_10,
            output [ADDRESS_WIDTH -1:0]mem_block_1_11,
            output [ADDRESS_WIDTH -1:0]mem_block_1_12,
            output [ADDRESS_WIDTH -1:0]mem_block_1_13,
            output [ADDRESS_WIDTH -1:0]mem_block_1_14,
            output [ADDRESS_WIDTH -1:0]mem_block_1_15,
            output [ADDRESS_WIDTH -1:0]mem_block_1_16,

            // input [N*LEN_WIDTH-1:0] len_0,
            // input [N*LEN_WIDTH-1:0] len_1,
            // input [N*LEN_WIDTH-1:0] len_2,
            // input [N*LEN_WIDTH-1:0] len_3,
            // input [N*LEN_WIDTH-1:0] len_4,
            // input [N*LEN_WIDTH-1:0] len_5,
            // input [N*LEN_WIDTH-1:0] len_6,
            // input [N*LEN_WIDTH-1:0] len_7,
            // input [N*LEN_WIDTH-1:0] len_8,
            // input [N*LEN_WIDTH-1:0] len_9,
            // input [N*LEN_WIDTH-1:0] len_10,
            // input [N*LEN_WIDTH-1:0] len_11,
            // input [N*LEN_WIDTH-1:0] len_12,
            // input [N*LEN_WIDTH-1:0] len_13,
            // input [N*LEN_WIDTH-1:0] len_14,
            // input [N*LEN_WIDTH-1:0] len_15,

            // output [$clog2(N)-1:0] lq_0,
            // output [$clog2(N)-1:0] lq_1,
            // output [$clog2(N)-1:0] lq_2,
            // output [$clog2(N)-1:0] lq_3,
            // output [$clog2(N)-1:0] lq_4,
            // output [$clog2(N)-1:0] lq_5,
            // output [$clog2(N)-1:0] lq_6,
            // output [$clog2(N)-1:0] lq_7,
            // output [$clog2(N)-1:0] lq_8,
            // output [$clog2(N)-1:0] lq_9,
            // output [$clog2(N)-1:0] lq_10,
            // output [$clog2(N)-1:0] lq_11,
            // output [$clog2(N)-1:0] lq_12,
            // output [$clog2(N)-1:0] lq_13,
            // output [$clog2(N)-1:0] lq_14,
            // output [$clog2(N)-1:0] lq_15,

            input [WIDTH-1:0] level_0_0,              // feed the length for each egress queue here
            input [WIDTH-1:0] level_0_1,
            input [WIDTH-1:0] level_0_2,
            input [WIDTH-1:0] level_0_3,
            input [WIDTH-1:0] level_0_4,
            input [WIDTH-1:0] level_0_5,
            input [WIDTH-1:0] level_0_6,
            input [WIDTH-1:0] level_0_7,
            input [WIDTH-1:0] level_0_8,
            input [WIDTH-1:0] level_0_9,
            input [WIDTH-1:0] level_0_10,
            input [WIDTH-1:0] level_0_11,
            input [WIDTH-1:0] level_0_12,
            input [WIDTH-1:0] level_0_13,
            input [WIDTH-1:0] level_0_14,
            input [WIDTH-1:0] level_0_15
            );
  
  wire [1:0]out_1[N/2-1:0];//require change
  wire [2:0]out_2[N/4-1:0];//require change
  wire [3:0]out_3[N/8-1:0];//require change
  // manually create log(N)-1 out wire variables and take care to set their data width correctly


  reg         pair_list_r_a_1 [0:N/2-1] [0:2*LEVEL-1];
  reg         pair_list_r_b_1 [0:N/2-1]; 

// LEVEL 2 (Data is 2 bits wide)
// Width: 2 bits | Depth: 2*LEVEL - 2
  reg [1:0]   pair_list_r_a_2 [0:N/4-1] [0:(2*LEVEL-2)-1];
  reg [1:0]   pair_list_r_b_2 [0:N/4-1];

// LEVEL 3 (Data is 3 bits wide)
// Width: 3 bits | Depth: 2*LEVEL - 4
  reg [2:0]   pair_list_r_a_3 [0:N/8-1] [0:(2*LEVEL-4)-1];
  reg [2:0]   pair_list_r_b_3 [0:N/8-1];

// LEVEL 4 (Data is 4 bits wide)
// Width: 4 bits | Depth: 2*LEVEL - 6
  reg [3:0]   pair_list_r_a_4 [0:N/16-1];
  reg [3:0]   pair_list_r_b_4 [0:N/16-1];
  wire [N*ADDRESS_WIDTH-1:0]mem;
  
  wire [N/2*ADDRESS_WIDTH-1:0]mem_block_4[N/8-1:0];
  wire [N/4*ADDRESS_WIDTH-1:0]mem_block_3[N/4-1:0];
  wire [N/8*ADDRESS_WIDTH-1:0]mem_block_2[N/2-1:0];
  wire [N/16*ADDRESS_WIDTH-1:0]mem_block_1[N-1:0];
  
  wire [N-1:0]bits[N-1:0];
  
  wire [N/2-1:0]control_4;
  wire [N/4-1:0]control_3[N/8-1:0];
  wire [N/8-1:0]control_2[N/4-1:0];
  wire [N/16-1:0]control_1[N/2-1:0];


  wire [LEVEL-1:0]lq[N-1:0];

  wire vr[N-1:0];

  wire [WIDTH-1+$clog2(N):0] level_4;



// assign lq_0 = lq[0];
// assign lq_1 = lq[1];
// assign lq_2 = lq[2];
// assign lq_3 = lq[3];
// assign lq_4 = lq[4];
// assign lq_5 = lq[5];
// assign lq_6 = lq[6];
// assign lq_7 = lq[7];
// assign lq_8 = lq[8];
// assign lq_9 = lq[9];
// assign lq_10 = lq[10];
// assign lq_11 = lq[11];
// assign lq_12 = lq[12];
// assign lq_13 = lq[13];
// assign lq_14 = lq[14];
// assign lq_15 = lq[15];

assign mem_block_1_1  = mem_block_1[0];
assign mem_block_1_2  = mem_block_1[1];
assign mem_block_1_3  = mem_block_1[2];
assign mem_block_1_4  = mem_block_1[3];
assign mem_block_1_5  = mem_block_1[4];
assign mem_block_1_6  = mem_block_1[5];
assign mem_block_1_7  = mem_block_1[6];
assign mem_block_1_8  = mem_block_1[7];
assign mem_block_1_9  = mem_block_1[8];
assign mem_block_1_10 = mem_block_1[9];
assign mem_block_1_11 = mem_block_1[10];
assign mem_block_1_12 = mem_block_1[11];
assign mem_block_1_13 = mem_block_1[12];
assign mem_block_1_14 = mem_block_1[13];
assign mem_block_1_15 = mem_block_1[14];
assign mem_block_1_16 = mem_block_1[15];

// Single-dimensional arrays for each level
wire [WIDTH-1+$clog2(N):0] level_1 [N/2-1:0];    // Level 1
wire [WIDTH-1+$clog2(N):0] level_2 [N/4-1:0];    // Level 2
wire [WIDTH-1+$clog2(N):0] level_3 [N/8-1:0];    // Level 3
                                              // Level 4: final greatest value

wire [WIDTH-1:0] level_0 [N-1:0];

assign level_0[0] = level_0_0; 
assign level_0[1] = level_0_1;
assign level_0[2] = level_0_2; 
assign level_0[3] = level_0_3;
assign level_0[4] = level_0_4; 
assign level_0[5] = level_0_5;
assign level_0[6] = level_0_6; 
assign level_0[7] = level_0_7;
assign level_0[8] = level_0_8; 
assign level_0[9] = level_0_9;
assign level_0[10] = level_0_10; 
assign level_0[11] = level_0_11;
assign level_0[12] = level_0_12; 
assign level_0[13] = level_0_13;
assign level_0[14] = level_0_14; 
assign level_0[15] = level_0_15;

// Connect the internal wire to the new input port

reg [LEVEL-1:0] level_4_delayed;

assign mem = mem_loc_in[level_4_delayed*(ADDRESS_WIDTH*N) +: (ADDRESS_WIDTH*N)];

assign lqd_trigger = (out_4 > 0) ? (1'b1 << level_4[$clog2(N)-1:0]) : {N{1'b0}};

assign level_4_out = level_4[$clog2(N)-1:0];

initial
begin
    level_4_delayed <= 0;
end
////////////////////////////////////////////// ADDER TREE ///////////////////////


always @(posedge clk or negedge rst_n) begin
    if (!rst_n)
        level_4_delayed <= 0;
    else
        level_4_delayed <= level_4[$clog2(N)-1:0];
end


  generate// require change
    genvar i;
    for (i = 0; i < N; i = i + 2) begin : adder_level_0
        adder_1 #(.WIDTH(1)) a1 (
            .clk(clk),
            .a(lqd_bit[i]),
            .b(lqd_bit[i + 1]),
            .out(out_1[i / 2])
        );
    end
    for (i = 0; i < N/4; i = i + 1) begin : adder_level_1
        adder_1 #(.WIDTH(2)) a2 (
            .clk(clk),
            .a(out_1[2*i]),
            .b(out_1[2*i+1]),
            .out(out_2[i])//change
        );
    end
    for (i = 0; i < N/8; i = i + 1) begin : adder_level_2
        adder_1 #(.WIDTH(3)) a3 (
            .clk(clk),
            .a(out_2[2*i]),
            .b(out_2[2*i+1]),//change
            .out(out_3[i])//change
        );
    end
    for (i = 0; i < N/16; i = i + 1) begin : adder_level_3
        adder_1 #(.WIDTH(4)) a4 (
            .clk(clk),
            .a(out_3[2*i]),
            .b(out_3[2*i+1]),//change
            .out(out_4)//change
        );
    end

  
///////////////////////////////////////////////ADDRESS DEMUX/////////////////////////////////////


  genvar j;
    for (i=0;i<N/2;i=i+1)
    begin
      mux_address #(.START(i), 
                  .END(i+N/2), 
                  .TOT(N), 
                  .ADDRESS_WIDTH(ADDRESS_WIDTH)) ma1 (
            clk,
            pair_list_r_a_4[0],
            mem[((i + N/2)+1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH], // Explicit slicing
            mem_block_4[1][(i + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH] // Correct slicing
        );
    end
    add_select #(.TOT(N), .ADDRESS_WIDTH(ADDRESS_WIDTH)) adl (clk,
                    control_4,
                    mem[N/2*ADDRESS_WIDTH - 1 : 0],
                    mem_block_4[0]
                    );
    ControlLUT #(N/2,$clog2(N/2)) c1 (pair_list_r_a_4[0],control_4);

    for (j=0;j<N/8;j=j+1)
    begin
      for (i=0;i<N/4;i=i+1)
      begin
        mux_address #(.START(i), 
                  .END(i+N/4), 
                  .TOT(N/2), 
                  .ADDRESS_WIDTH(ADDRESS_WIDTH)) ma2 (clk,
                  pair_list_r_a_3[j] [(2*LEVEL-4)-1],
                  mem_block_4[j][((i + N/4) + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH], // Explicit slicing
                  mem_block_3[2*j+1][(i + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH]
                  );
      end
      add_select #(.TOT(N/2), .ADDRESS_WIDTH(ADDRESS_WIDTH)) ad2 (clk,
                    control_3[j],
                    mem_block_4[j][N/4*ADDRESS_WIDTH - 1 : 0],
                    mem_block_3[2*j]
                    );
      
      ControlLUT #(N/4,$clog2(N/4)) c2 (pair_list_r_a_3[j] [(2*LEVEL-4)-1],control_3[j]);
    end

      
    for (j=0;j<N/4;j=j+1)
      begin 
      for (i=0;i<N/8;i=i+1)
      begin  
    
        mux_address #(.START(i), 
                  .END(i+N/8), 
                  .TOT(N/4), 
                  .ADDRESS_WIDTH(ADDRESS_WIDTH)) ma3 (clk,
                  pair_list_r_a_2[j][(2*LEVEL-2)-1],
                  mem_block_3[j][((i + N/8) + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH], // Explicit slicing
                  mem_block_2[2*j+1][(i + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH]
                  );
      end
      add_select #(.TOT(N/4), .ADDRESS_WIDTH(ADDRESS_WIDTH)) ad3 (clk,
                    control_2[j],
                    mem_block_3[j][N/8*ADDRESS_WIDTH - 1 : 0],
                    mem_block_2[2*j]
                    );

      ControlLUT #(N/8,$clog2(N/8)) c3 (pair_list_r_a_2[j][(2*LEVEL-2)-1],control_2[j]);
    end

    for (j=0;j<N/2;j=j+1)
      begin
      for (i=0;i<N/16;i=i+1)
      begin
        mux_address #(.START(i), 
                  .END(i+N/16), 
                  .TOT(N/8), 
                  .ADDRESS_WIDTH(ADDRESS_WIDTH)) ma4 (clk,
                  pair_list_r_a_1[j][2*(LEVEL)-1],
                  mem_block_2[j][((i + N/16) + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH], // Explicit slicing
                  mem_block_1[2*j+1][(i + 1) * ADDRESS_WIDTH - 1 : i * ADDRESS_WIDTH]
                  );
      end
      
        add_select #(.TOT (N/8), .ADDRESS_WIDTH(ADDRESS_WIDTH)) ad4 (clk,
                    control_1[j],
                    mem_block_2[j][N/16*ADDRESS_WIDTH - 1 : 0],
                    mem_block_1[2*j]
                    );

        ControlLUT #(N/16,$clog2(N/16)) c4 (pair_list_r_a_1[j][2*(LEVEL)-1],control_1[j]);
    end

///////////////////////////////////////////////////////////// N**2 comparators /////////////////////////

    // for (j = 0;j<N;j=j+1)
    // begin
    //     for (i = 0; i < N; i = i + 1) begin : ComparatorGen
    //         Comparator #(LEN_WIDTH,N) u_Comparator (
    //             .A(len[j][(i+1)*LEN_WIDTH-1  -: LEN_WIDTH]), // Extract 8-bit chunk for A
    //             .B(out_4), // Extract 8-bit chunk for B
    //             .Greater(bits[j][i]) // Extract 8-bit chunk for Greater
    //         );
    //     end
    // end

    // for (i = 0;i<N;i=i+1)
    // begin
        
    //     priority_encode_log #
    //     (
    //         .NUM_OF_SUBLIST(N),
    //         .width(N),
    //         .log_width($clog2(N))
    //     )
    //     e1
    //     (
    //     .decode(bits[i]),
    //     .encode_reg(lq[i]),
    //     .valid_reg(vr[i])
    //     );
    // end





/////////////////////////////////////////////////SHIFTER///////////////////////////////////////////////
    

    


    
        for (i = 0; i < N/2; i = i + 1) begin : level_0_to_1
            
            // 1. Calculate the Width once for readability
            localparam ID_W = $clog2(N);

            // 2. Assign the loop indices to SIZED WIRES
            // This forces the 32-bit integer '2*i' to become a clean vector
            wire [ID_W-1:0] id_a = (2*i);
            wire [ID_W-1:0] id_b = (2*i + 1);

            comparator #(
                .WIDTH(WIDTH),
                .LEVEL(ID_W),
                .N(N)
            ) comp_inst (
                .clk(clk),
                // 3. Use the wires in the concatenation
                .a( {level_0[2*i],   id_a} ), 
                .b( {level_0[2*i+1], id_b} ),
                .greater(level_1[i])
            );
        end
    


    // Comparators for level 1 -> level 2
        for (i = 0; i < N/4; i = i + 1) begin : level_1_to_2
            comparator #(.WIDTH(WIDTH),.LEVEL($clog2(N)),.N(N)) comp_inst (
                .clk(clk),
                .a(level_1[2*i]),
                .b(level_1[2*i+1]),
                .greater(level_2[i])
            );
        end

    // Comparators for level 2 -> level 3
        for (i = 0; i < N/8; i = i + 1) begin : level_2_to_3
            comparator #(.WIDTH(WIDTH),.LEVEL($clog2(N)),.N(N)) comp_inst (
                .clk(clk),
                .a(level_2[2*i]),
                .b(level_2[2*i+1]),
                .greater(level_3[i])
            );
        end
    

    // Comparator for level 3 -> level 4

        for (i = 0; i < N/16; i = i + 1) begin : level_3_to_4
            comparator #(.WIDTH(WIDTH),.LEVEL($clog2(N)),.N(N)) comp_inst (
                .clk(clk),
                .a(level_3[2*i]),
                .b(level_3[2*i+1]),
                .greater(level_4)
            );
        end

endgenerate

  //   // Higher levels of the tree
  //   for (j = 1; j <= LEVEL-1; j = j + 1) begin : adder_tree_levels
  //       for (i = 0; i < N >> j; i = i + 2) begin : adder_level
  //           adder_1 #(.WIDTH(LEVEL)) b ( // Change WIDTH dynamically for each level
  //               .clk(clk),
  //               .a(out[j - 1][i]),
  //               .b(out[j - 1][i + 1]),
  //               .out(out[j][i / 2])
  //           );
  //       end
  //   end
  // endgenerate



/////////////////////////////////////////////////////////////////////////////





///////////////////////////////////////////////////////////////////////////////
  
  integer g; 
  integer t;
  always@(posedge clk)
  begin
    
    for(g=0;g<N;g=g+2)
    begin
        pair_list_r_a_1[g/2][0] <= lqd_bit[g];
        for(t = 0; t<2*(LEVEL)-1 ; t=t+1 )
        pair_list_r_a_1[g/2][t+1] <= pair_list_r_a_1[g/2][t]; //resource intensive 
        pair_list_r_b_1[g/2] <= lqd_bit[g+1];
    end

    for(g=0;g<N/2;g=g+2)
    begin
        pair_list_r_a_2[g/2][0] <= out_1[g];
        for(t = 0; t<(2*LEVEL-2)-1 ; t=t+1 )
        pair_list_r_a_2[g/2][t+1] <= pair_list_r_a_2[g/2][t];
        pair_list_r_b_2[g/2][1:0] <= out_1[g+1];
    end


    for(g=0;g<N/4;g=g+2)
    begin
        pair_list_r_a_3[g/2][0] <= out_2[g];
        for(t = 0; t<(2*LEVEL-4)-1 ; t=t+1 )
        pair_list_r_a_3[g/2][t+1] <= pair_list_r_a_3[g/2][t]; //resource intensive
        pair_list_r_b_3[g/2][2:0] <= out_2[g+1];
    end


    for(g=0;g<N/8;g=g+2)
    begin
        pair_list_r_a_4[g/2] <= out_3[g];
        pair_list_r_b_4[g/2][3:0] <= out_3[g+1];
    end

    // memory fetch
    // priority 


    

  end
  
endmodule