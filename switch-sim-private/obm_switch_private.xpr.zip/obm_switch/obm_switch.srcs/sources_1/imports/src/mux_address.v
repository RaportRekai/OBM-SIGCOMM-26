module mux_address #(
    parameter START = 0, 
    parameter END = 16,
    parameter TOT = 16,
    parameter ADDRESS_WIDTH = 6
) (
    input clk,
    input [$clog2(END-START):0] cntrl, // Correct width of control signal
    input [(TOT/2+1)*ADDRESS_WIDTH-1:0] memory, // Flattened memory input
    output reg [ADDRESS_WIDTH-1:0] mem_block_1 // Selected memory block
);
    integer i;

    always @ (posedge clk) begin
        mem_block_1 <= memory[ (cntrl + 1)*ADDRESS_WIDTH-1 -:ADDRESS_WIDTH];
    end
endmodule