
module add_select #(parameter TOT = 8, parameter ADDRESS_WIDTH = 6) (input clk,
                                        input [TOT/2-1:0]ctrl,
                                        input [TOT/2*ADDRESS_WIDTH-1:0]mem,
                                        output reg [TOT/2*ADDRESS_WIDTH-1:0]mem_block);
integer i;
always@(posedge clk)
begin
    for(i=0;i<TOT/2;i=i+1)
    begin
        if (ctrl[i] == 1)
            mem_block[(i+1)*ADDRESS_WIDTH-1 -: ADDRESS_WIDTH]<= mem[(i+1)*ADDRESS_WIDTH-1 -: ADDRESS_WIDTH];
        else
            mem_block[(i+1)*ADDRESS_WIDTH-1 -: ADDRESS_WIDTH]<= {ADDRESS_WIDTH{1'b0}};
    end
end
endmodule
