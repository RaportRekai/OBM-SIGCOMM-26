module obm_queue #(
    parameter PD_WIDTH = 18,    // Packet Width (18 bits)
    parameter N = 8,           // Banking Factor
    parameter DEPTH_LOG = 11,   // Log2 of Max Depth (for pointer width)
    parameter TOTAL_MEMORY = 5594 // NEW: Explicit memory limit
)(
    input wire clk,
    input wire rst_n,

    // --- PORT A (Tail / Write) ---
    input wire we_a,                    
    input wire [PD_WIDTH-1:0] din_a,    
    input wire lqd_trigger,             
    input wire [$clog2(N):0] drop_k,  
    output wire [PD_WIDTH*N-1:0] dout_a, 

    // --- PORT B (Head / Read) ---
    input wire re_b,                    
    output wire [PD_WIDTH*N-1:0] dout_b,
    
    // --- Queue Status ---
    output reg [DEPTH_LOG-1:0] current_len, 
    output reg valid_out,
    input wire [$clog2(N)-1:0] tdm_idx
);

    // =========================================================
    // 1. POINTERS WITH EXPLICIT RECYCLING
    // =========================================================
    reg [DEPTH_LOG-1:0] w_ptr;
    reg [DEPTH_LOG-1:0] r_ptr;
    wire is_empty;
    
    assign is_empty = (w_ptr == r_ptr);
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            w_ptr <= 0;
            valid_out <= 0;
            r_ptr <= 0;
        end else begin
            
            // -------------------------------------------------
            // TAIL LOGIC (Write & Drop)
            // -------------------------------------------------
            if (lqd_trigger && re_b) begin
                // Drop Logic: Subtract drop_k with wrap-around protection
                if (w_ptr >= drop_k) begin
                    w_ptr <= w_ptr - drop_k;
                end else begin
                    // Wrap around backwards: (Total - (drop - current))
                    w_ptr <= TOTAL_MEMORY - (drop_k - w_ptr);
                end
            end 
            else if (we_a) begin
                // Increment Logic: Explicit Recycle
                if (w_ptr == TOTAL_MEMORY - 1)
                    w_ptr <= 0;
                else
                    w_ptr <= w_ptr + 1;
            end

            // -------------------------------------------------
            // HEAD LOGIC (Read)
            // -------------------------------------------------
            if (re_b && !is_empty) begin
                // Increment Logic: Explicit Recycle
                if (r_ptr == TOTAL_MEMORY - 1)
                    r_ptr <= 0;
                else
                    r_ptr <= r_ptr + 1;
                    
                valid_out <= 1'b1; 
            end else begin
                valid_out <= 1'b0;
            end
        end
    end

    // =========================================================
    // 2. LENGTH CALCULATION (NON-POWER-OF-2 COMPATIBLE)
    // =========================================================
    // Standard binary subtraction (w - r) fails if we wrap at 
    // an arbitrary number like 1398. We need circular distance.
    
    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            current_len <= 0;
        end else begin
            if (w_ptr >= r_ptr) begin
                // Normal case: Tail is ahead of Head
                current_len <= w_ptr - r_ptr;
            end else begin
                // Wrapped case: Tail has wrapped around
                // Len = (End - Head) + Tail
                current_len <= (TOTAL_MEMORY - r_ptr) + w_ptr;
            end
        end
    end
    
    // =========================================================
    // 3. ADDRESS DECODING & MEMORY
    // =========================================================
    // Note: We define memory array size using DEPTH_LOG to ensure 
    // it physically fits, even if we logically cap usage at TOTAL_MEMORY.
    
    localparam ROW_BITS = DEPTH_LOG - $clog2(N);
    localparam BANK_BITS = $clog2(N);

    // Decoding remains bit-slice based assuming N is Power of 2 (8, 16).
    // If N is NOT power of 2, this needs modulo/division operators.
    wire [ROW_BITS-1:0]   tail_row  = w_ptr[DEPTH_LOG-1 : BANK_BITS];
    wire [BANK_BITS-1:0]  tail_bank = w_ptr[BANK_BITS-1 : 0];
    wire [ROW_BITS-1:0]   head_row  = r_ptr[DEPTH_LOG-1 : BANK_BITS];

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : banks
            
            // Physical memory depth per bank
            (* ram_style = "block" *)
            reg [PD_WIDTH-1:0] mem_array [0:(1<<ROW_BITS)-1];
            reg [PD_WIDTH-1:0] bank_out_a;
            reg [PD_WIDTH-1:0] bank_out_b;

            // Write Port
            always @(posedge clk) begin
                if (we_a && !lqd_trigger && (tail_bank == i)) begin
                    // Safety check: Ensure we don't write out of bounds 
                    // (Though w_ptr logic above prevents this)
                    mem_array[tail_row] <= din_a;
                end else if (lqd_trigger) begin
                    bank_out_a <= mem_array[tail_row];
                end
            end
            
            // Read Port
            always @(posedge clk) begin
                if (re_b) begin
                    bank_out_b <= mem_array[head_row];
                end
            end

            assign dout_a[i*PD_WIDTH +: PD_WIDTH] = bank_out_a;
            assign dout_b[i*PD_WIDTH +: PD_WIDTH] = bank_out_b;
            
        end
    endgenerate

endmodule