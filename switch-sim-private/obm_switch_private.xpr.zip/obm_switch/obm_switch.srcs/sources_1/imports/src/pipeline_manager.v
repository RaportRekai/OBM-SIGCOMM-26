module pipeline_manager #(
    parameter N = 16,
    parameter K = 8  // Latency
)(
    input wire clk,
    input wire rst_n,
    
    // Inputs (From WAC)
    input wire [N-1:0] we_in,
    input wire [N-1:0] lqd_in,        // NEW: LQD Input
    input wire [N*4-1:0] dest_in_flat,
    
    // Outputs (Delayed)
    output wire [N-1:0] we_out,
    output wire [N-1:0] lqd_out,      // NEW: LQD Output (Delayed)
    output wire [N*4-1:0] dest_out_flat
);

    // Internal Shift Register Memory
    // Width INCREASED to 6 bits:
    // [5] = WE
    // [4] = LQD  <-- Added
    // [3:0] = Dest
    reg [$clog2(N)+1:0] pipe_regs [0 : (N*K)-1];
    
    integer p, s;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for(p=0; p < N*K; p=p+1) pipe_regs[p] <= 0;
        end else begin
            for(p=0; p < N; p=p+1) begin
                // 1. Shift Data In (Stage 0)
                // Pack WE, LQD, and Dest into one 6-bit chunk
                pipe_regs[p*K + 0] <= { 
                    we_in[p], 
                    lqd_in[p],                  // Pack LQD bit here
                    dest_in_flat[p*$clog2(N) +: $clog2(N)] 
                };
                
                // 2. Shift Through Pipeline (Stages 1 to K-1)
                for(s=1; s<K; s=s+1) begin
                    pipe_regs[p*K + s] <= pipe_regs[p*K + (s-1)];
                end
            end
        end
    end

    // Unpack Output Logic
    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : unpack
            // Read from the last stage (K-1)
            // Unpack based on the indices we defined above
            assign we_out[i]           = pipe_regs[i*K + (K-1)][$clog2(N)+1];
            assign lqd_out[i]          = pipe_regs[i*K + (K-1)][$clog2(N)]; // Unpack LQD
            assign dest_out_flat[i*$clog2(N) +: $clog2(N)] = pipe_regs[i*K + (K-1)][$clog2(N)-1:0];
        end
    endgenerate

endmodule