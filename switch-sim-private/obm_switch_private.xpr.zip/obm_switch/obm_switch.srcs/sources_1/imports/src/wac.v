module wac #(
    parameter N = 16, 
    parameter DEPTH_LOG = 11,
    parameter TOTAL_MEM_CAPACITY = 16 * (1 << 7),
    parameter LATENCY = 8  // New Parameter (Matches 'K' from top level)
)(
    input  wire clk,
    input  wire [N-1:0] we,
    
    // Flattened Egress Port Destinations
    input  wire [$clog2(N)-1:0] eg_port_0, eg_port_1, eg_port_2, eg_port_3,
    input  wire [$clog2(N)-1:0] eg_port_4, eg_port_5, eg_port_6, eg_port_7,
    input  wire [$clog2(N)-1:0] eg_port_8, eg_port_9, eg_port_10, eg_port_11,
    input  wire [$clog2(N)-1:0] eg_port_12, eg_port_13, eg_port_14, eg_port_15,
    
    input  wire [$clog2(N)-1:0] long_q,
    input  wire [$clog2(TOTAL_MEM_CAPACITY):0] left,
    
    // Outputs
    output wire [N-1:0] lqd_bit_gen,
    output wire [N-1:0] drop_bit_gen,
    output wire [N-1:0] valid_we
);

    // 1. Array Packing 
    wire [$clog2(N)-1:0] eg_port [0:N-1];
    assign eg_port[0] = eg_port_0;   assign eg_port[1] = eg_port_1;       
    assign eg_port[2] = eg_port_2;   assign eg_port[3] = eg_port_3;
    assign eg_port[4] = eg_port_4;   assign eg_port[5] = eg_port_5;
    assign eg_port[6] = eg_port_6;   assign eg_port[7] = eg_port_7;
    assign eg_port[8] = eg_port_8;   assign eg_port[9] = eg_port_9;
    assign eg_port[10] = eg_port_10; assign eg_port[11] = eg_port_11;
    assign eg_port[12] = eg_port_12; assign eg_port[13] = eg_port_13;
    assign eg_port[14] = eg_port_14; assign eg_port[15] = eg_port_15;

    // 2. Define Base Threshold
    // Formula: (LATENCY - 1) * 16
    // With Latency=8, N=16 -> (7 * 16) = 112
    localparam BASE_THRESHOLD = (LATENCY - 1) * N - 50 ;

    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : admission_logic
            
            // 3. Calculate Specific Threshold for this Port
            // Port 0: needs left > 112
            // Port 1: needs left > 113
            // ...
            // Port 15: needs left > 127
//            wire [$clog2(TOTAL_MEM_CAPACITY):0] port_threshold;
//            assign port_threshold = BASE_THRESHOLD + i;

            // 4. Update Status Bits (Optional: Sync these with the new valid_we logic)
            // If valid_we goes low, we typically want drop_bit to go high.
            // Current logic: Drop if we match LQD target OR if we fail the threshold check
            assign lqd_bit_gen[i]  = (long_q!=eg_port[i] && we[i] && (left <=BASE_THRESHOLD));
            assign drop_bit_gen[i] = (long_q==eg_port[i] && we[i] && (left <=BASE_THRESHOLD));

            // 5. Write Admission Check
            // Admit ONLY if:
            //    a) User wants to write
            //    b) We have strictly more space than the calculated threshold
            assign valid_we[i] = we[i] && (left >BASE_THRESHOLD);

        end
    endgenerate

endmodule