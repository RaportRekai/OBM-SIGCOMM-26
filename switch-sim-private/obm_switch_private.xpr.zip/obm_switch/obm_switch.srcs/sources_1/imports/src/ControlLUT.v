module ControlLUT #(parameter N = 8, BIT_WIDTH = 7)(
    input [BIT_WIDTH:0] count,       // 4-bit count input
    output [N-1:0] ctrl        // 8-bit control wire
);
    assign ctrl = (1 << count) - 1;
endmodule
