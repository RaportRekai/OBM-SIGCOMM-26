module wrapper_n_16 (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    output wire [7:0] dummy_checksum
);

    wire clk_mem;
    wire clk_wiz_locked;

    clk_wiz_7 clk_gen (
        .clk_out1(clk_mem),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    // -------------------------------------------------------------------------
    // Internal stimulus registers
    // These replace the huge top-level IOs.
    // -------------------------------------------------------------------------
    reg [15:0] lqd_bit;
    reg [(16 * 6) - 1 : 0] mem_loc_in;

    reg [7:0] level_0_0;
    reg [7:0] level_0_1;
    reg [7:0] level_0_2;
    reg [7:0] level_0_3;
    reg [7:0] level_0_4;
    reg [7:0] level_0_5;
    reg [7:0] level_0_6;
    reg [7:0] level_0_7;
    reg [7:0] level_0_8;
    reg [7:0] level_0_9;
    reg [7:0] level_0_10;
    reg [7:0] level_0_11;
    reg [7:0] level_0_12;
    reg [7:0] level_0_13;
    reg [7:0] level_0_14;
    reg [7:0] level_0_15;

    always @(posedge clk_mem or negedge rst_clean_n) begin
        if (!rst_clean_n) begin
            lqd_bit    <= 16'd0;
            mem_loc_in <= 96'b0;

            level_0_0  <= 8'd0;
            level_0_1  <= 8'd1;
            level_0_2  <= 8'd2;
            level_0_3  <= 8'd3;
            level_0_4  <= 8'd4;
            level_0_5  <= 8'd5;
            level_0_6  <= 8'd6;
            level_0_7  <= 8'd7;
            level_0_8  <= 8'd8;
            level_0_9  <= 8'd9;
            level_0_10 <= 8'd10;
            level_0_11 <= 8'd11;
            level_0_12 <= 8'd12;
            level_0_13 <= 8'd13;
            level_0_14 <= 8'd14;
            level_0_15 <= 8'd15;
        end else begin
            lqd_bit    <= lqd_bit + 1'b1;
            mem_loc_in <= mem_loc_in + 1'b1;

            level_0_0  <= level_0_0  + 1'b1;
            level_0_1  <= level_0_1  + 2'd2;
            level_0_2  <= level_0_2  + 2'd3;
            level_0_3  <= level_0_3  + 3'd4;
            level_0_4  <= level_0_4  + 3'd5;
            level_0_5  <= level_0_5  + 3'd6;
            level_0_6  <= level_0_6  + 3'd7;
            level_0_7  <= level_0_7  + 4'd8;
            level_0_8  <= level_0_8  + 4'd9;
            level_0_9  <= level_0_9  + 4'd10;
            level_0_10 <= level_0_10 + 4'd11;
            level_0_11 <= level_0_11 + 4'd12;
            level_0_12 <= level_0_12 + 4'd13;
            level_0_13 <= level_0_13 + 4'd14;
            level_0_14 <= level_0_14 + 4'd15;
            level_0_15 <= level_0_15 + 5'd16;
        end
    end

    // -------------------------------------------------------------------------
    // DUT outputs
    // -------------------------------------------------------------------------
    wire [4:0] out_4;

    wire [3:0]  level_4_out;
    wire [15:0] lqd_trigger;

    wire [5:0] mem_block_1_1;
    wire [5:0] mem_block_1_2;
    wire [5:0] mem_block_1_3;
    wire [5:0] mem_block_1_4;
    wire [5:0] mem_block_1_5;
    wire [5:0] mem_block_1_6;
    wire [5:0] mem_block_1_7;
    wire [5:0] mem_block_1_8;
    wire [5:0] mem_block_1_9;
    wire [5:0] mem_block_1_10;
    wire [5:0] mem_block_1_11;
    wire [5:0] mem_block_1_12;
    wire [5:0] mem_block_1_13;
    wire [5:0] mem_block_1_14;
    wire [5:0] mem_block_1_15;
    wire [5:0] mem_block_1_16;

    // -------------------------------------------------------------------------
    // DUT instance
    // -------------------------------------------------------------------------
    main_n_16_mod #(
        .N(16),
        .LEVEL(4),
        .ADDRESS_WIDTH(6),
        .WIDTH(8)
    ) uut (
        .clk(clk_mem),
        .rst_n(rst_clean_n),

        .lqd_bit(lqd_bit),
        .out_4(out_4),

        .mem_loc_in(mem_loc_in),
        .level_4_out(level_4_out),
        .lqd_trigger(lqd_trigger),

        .mem_block_1_1(mem_block_1_1),
        .mem_block_1_2(mem_block_1_2),
        .mem_block_1_3(mem_block_1_3),
        .mem_block_1_4(mem_block_1_4),
        .mem_block_1_5(mem_block_1_5),
        .mem_block_1_6(mem_block_1_6),
        .mem_block_1_7(mem_block_1_7),
        .mem_block_1_8(mem_block_1_8),
        .mem_block_1_9(mem_block_1_9),
        .mem_block_1_10(mem_block_1_10),
        .mem_block_1_11(mem_block_1_11),
        .mem_block_1_12(mem_block_1_12),
        .mem_block_1_13(mem_block_1_13),
        .mem_block_1_14(mem_block_1_14),
        .mem_block_1_15(mem_block_1_15),
        .mem_block_1_16(mem_block_1_16),

        .level_0_0(level_0_0),
        .level_0_1(level_0_1),
        .level_0_2(level_0_2),
        .level_0_3(level_0_3),
        .level_0_4(level_0_4),
        .level_0_5(level_0_5),
        .level_0_6(level_0_6),
        .level_0_7(level_0_7),
        .level_0_8(level_0_8),
        .level_0_9(level_0_9),
        .level_0_10(level_0_10),
        .level_0_11(level_0_11),
        .level_0_12(level_0_12),
        .level_0_13(level_0_13),
        .level_0_14(level_0_14),
        .level_0_15(level_0_15)
    );

    // -------------------------------------------------------------------------
    // Dummy checksum to prevent Vivado from optimizing away the DUT
    // -------------------------------------------------------------------------
    assign dummy_checksum = ^{
        out_4,
        level_4_out,
        lqd_trigger,

        mem_block_1_1,
        mem_block_1_2,
        mem_block_1_3,
        mem_block_1_4,
        mem_block_1_5,
        mem_block_1_6,
        mem_block_1_7,
        mem_block_1_8,
        mem_block_1_9,
        mem_block_1_10,
        mem_block_1_11,
        mem_block_1_12,
        mem_block_1_13,
        mem_block_1_14,
        mem_block_1_15,
        mem_block_1_16
    };

endmodule