module port_4_wrapper (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    input  wire [3:0] we_in,

    input wire [1:0] eg_port_in_0,
    input wire [1:0] eg_port_in_1,
    input wire [1:0] eg_port_in_2,
    input wire [1:0] eg_port_in_3,

    output wire [15:0] egress_port_0,
    output wire [15:0] egress_port_1,
    output wire [15:0] egress_port_2,
    output wire [15:0] egress_port_3,

    output wire [7:0] dummy_checksum
);

    // Clocking Wizard outputs
    wire clk_195;        // 195.3125 MHz
    wire clk_24;         // 24.4140625 MHz
    wire clk_wiz_locked;

    clk_wiz_0 clk_gen (
        .clk_out1(clk_195),
        .clk_out2(clk_24),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    // Hold design in reset until clock wizard locks
    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    switch_4_port uut (
        .clk_sys(clk_24),
        .clk_mem(clk_195),
        .rst_n(rst_clean_n),

        .we_in(we_in),

        .eg_port_in_0(eg_port_in_0),
        .eg_port_in_1(eg_port_in_1),
        .eg_port_in_2(eg_port_in_2),
        .eg_port_in_3(eg_port_in_3),

        .egress_port_0(egress_port_0),
        .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),
        .egress_port_3(egress_port_3),

        .dummy_checksum(dummy_checksum)
    );

endmodule