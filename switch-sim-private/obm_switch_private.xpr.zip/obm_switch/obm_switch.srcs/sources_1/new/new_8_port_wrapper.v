module new_8_port_wrapper (
    input  wire clk_mem_p,   // physical 300 MHz differential clock +
    input  wire clk_mem_n,   // physical 300 MHz differential clock -
    input  wire rst_n,

    input  wire [7:0] we_in,

    input wire [2:0] eg_port_in_0,
    input wire [2:0] eg_port_in_1,
    input wire [2:0] eg_port_in_2,
    input wire [2:0] eg_port_in_3,
    input wire [2:0] eg_port_in_4,
    input wire [2:0] eg_port_in_5,
    input wire [2:0] eg_port_in_6,
    input wire [2:0] eg_port_in_7,

    output wire [15:0] egress_port_0,
    output wire [15:0] egress_port_1,
    output wire [15:0] egress_port_2,
    output wire [15:0] egress_port_3,
    output wire [15:0] egress_port_4,
    output wire [15:0] egress_port_5,
    output wire [15:0] egress_port_6,
    output wire [15:0] egress_port_7,

    output wire [7:0] dummy_checksum
);

    wire clk_mem;
    wire clk_wiz_locked;

    clk_wiz_3 clk_gen (
        .clk_out1(clk_mem),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    switch_8_port uut (
        .clk_mem(clk_mem),
        .rst_n(rst_clean_n),

        .we_in(we_in),

        .eg_port_in_0(eg_port_in_0),
        .eg_port_in_1(eg_port_in_1),
        .eg_port_in_2(eg_port_in_2),
        .eg_port_in_3(eg_port_in_3),
        .eg_port_in_4(eg_port_in_4),
        .eg_port_in_5(eg_port_in_5),
        .eg_port_in_6(eg_port_in_6),
        .eg_port_in_7(eg_port_in_7),

        .egress_port_0(egress_port_0),
        .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),
        .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),
        .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),
        .egress_port_7(egress_port_7),

        .dummy_checksum(dummy_checksum)
    );

endmodule