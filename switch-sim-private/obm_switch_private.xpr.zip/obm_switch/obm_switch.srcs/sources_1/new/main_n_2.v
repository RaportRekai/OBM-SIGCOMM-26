module main_n_2  #(
            parameter N = 2,
            parameter LEVEL = $clog2(N), // 1
            parameter ADDRESS_WIDTH = 6,
            parameter WIDTH = 8,
            parameter LEN_WIDTH = 8
        ) (
            input clk,
            input rst_n,
            input [N-1:0] lqd_bit,
            
            output [LEVEL:0] out_1, // Total active count (max 2)

            output [ADDRESS_WIDTH -1:0] mem_block_1_1,
            output [ADDRESS_WIDTH -1:0] mem_block_1_2,

            input [(N * ADDRESS_WIDTH*N) - 1 : 0] mem_loc_in,
            output wire [$clog2(N)-1:0] level_2_out, 
            output wire [N-1:0] lqd_trigger,
            
            input [WIDTH-1:0] level_0_0,
            input [WIDTH-1:0] level_0_1,
            
            output [WIDTH-1+$clog2(N):0] level_1
            );

  // --------------------------------------------------------
  // 1. Internal Wires & Registers
  // --------------------------------------------------------
  // Delay Line (Depth = 1 for N=2 pipeline)
  reg pair_list_r_a_1 [0:1]; // Depth 0 (Single reg)
  
  reg [N*ADDRESS_WIDTH-1:0] mem;
  wire [N/2*ADDRESS_WIDTH-1:0] mem_block_1 [N-1:0]; 
  wire [N/2-1:0] control_1; 

  wire [WIDTH-1:0] level_0 [N-1:0];
  assign level_0[0] = level_0_0; 
  assign level_0[1] = level_0_1;

  // Memory Selection (Zero Latency)
  
  assign lqd_trigger = (out_1 > 0) ? (1'b1 << level_1[$clog2(N)-1:0]) : {N{1'b0}};
  assign level_2_out = level_1[$clog2(N)-1:0];

  assign mem_block_1_1 = mem_block_1[0];
  assign mem_block_1_2 = mem_block_1[1];

  // --------------------------------------------------------
  // 2. Adder Tree (Resource Counting)
  // --------------------------------------------------------
  // Level 1 Sum (Final)
  adder_1 #(.WIDTH(1)) a1 (
      .clk(clk),
      .a(lqd_bit[0]),
      .b(lqd_bit[1]),
      .out(out_1)
  );

  // --------------------------------------------------------
  // 3. Address Steering Logic
  // --------------------------------------------------------
  // LEVEL 1: Top Split (2 ports -> 1 Left / 1 Right)
  
  // A. Left Branch
  add_select #(.TOT(N), .ADDRESS_WIDTH(ADDRESS_WIDTH)) adl (
      .clk(clk),
      .ctrl(control_1),
      .mem(mem),
      .mem_block(mem_block_1[0]) 
  );
  ControlLUT #(N/2, $clog2(N/2)) c1 (pair_list_r_a_1[1], control_1);

  // B. Right Branch (1 Mux needed)
  mux_address #(
      .START(0), 
      .END(1), 
      .TOT(2*N), 
      .ADDRESS_WIDTH(ADDRESS_WIDTH)
  ) ma1 (
      .clk(clk),
      .cntrl(pair_list_r_a_1[1]),
      .memory(mem), 
      .mem_block_1(mem_block_1[1])
  );

  // --------------------------------------------------------
  // 4. Comparator Tree
  // --------------------------------------------------------
  wire [LEVEL-1:0] id_a = 0;
  wire [LEVEL-1:0] id_b = 1;

  comparator #(.WIDTH(WIDTH), .LEVEL($clog2(N)), .N(N)) comp_inst (
      .clk(clk),
      .a( {level_0[0], id_a} ), 
      .b( {level_0[1], id_b} ),
      .greater(level_1)
  );

  // --------------------------------------------------------
  // 5. Sequential Logic
  // --------------------------------------------------------
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        // 1. ASYNCHRONOUS RESET CONDITION
        // When reset goes LOW, clear the register.
        pair_list_r_a_1[0] <= 1'b0; 
        pair_list_r_a_1[1] <= 1'b0; 
    end else begin
        mem <= mem_loc_in[level_1[$clog2(N)-1:0]*(ADDRESS_WIDTH*N) +: (ADDRESS_WIDTH*N)];
        // 2. NORMAL CLOCK OPERATION
        // When reset is HIGH (inactive), capture input on clock edge.
        pair_list_r_a_1[0] <= lqd_bit[0]; 
        pair_list_r_a_1[1] <= pair_list_r_a_1[0]; 
    end
  end

endmodule