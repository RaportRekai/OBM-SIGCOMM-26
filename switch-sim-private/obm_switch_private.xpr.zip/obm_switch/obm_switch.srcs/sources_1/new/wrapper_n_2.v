module wrapper_n_2 (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    output wire [7:0] dummy_checksum
);

    wire clk_mem;
    wire clk_wiz_locked;

    clk_wiz_6 clk_gen (
        .clk_out1(clk_mem),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    // -------------------------------------------------------------------------
    // Internal stimulus registers
    // These replace the huge top-level IOs.
    // -------------------------------------------------------------------------
    reg [1:0] lqd_bit;
    reg [(2 * 6 ) - 1 : 0] mem_loc_in;

    reg [7:0] level_0_0;
    reg [7:0] level_0_1;

    always @(posedge clk_mem or negedge rst_clean_n) begin
        if (!rst_clean_n) begin
            lqd_bit    <= 2'b00;
            mem_loc_in <= 12'd0;

            level_0_0 <= 8'd0;
            level_0_1 <= 8'd1;
        end else begin
            lqd_bit    <= lqd_bit + 1'b1;
            mem_loc_in <= mem_loc_in + 1'b1;

            level_0_0 <= level_0_0 + 1'b1;
            level_0_1 <= level_0_1 + 2'd2;
        end
    end

    // -------------------------------------------------------------------------
    // DUT outputs
    // -------------------------------------------------------------------------
    wire [1:0] out_1;

    wire [5:0] mem_block_1_1;
    wire [5:0] mem_block_1_2;

    wire       level_2_out;
    wire [1:0] lqd_trigger;

    wire [9:0] level_1;

    // -------------------------------------------------------------------------
    // DUT instance
    // -------------------------------------------------------------------------
    main_n_2_mod #(
        .N(2),
        .LEVEL(1),
        .ADDRESS_WIDTH(6),
        .WIDTH(8),
        .LEN_WIDTH(8)
    ) uut (
        .clk(clk_mem),
        .rst_n(rst_clean_n),

        .lqd_bit(lqd_bit),

        .out_1(out_1),

        .mem_block_1_1(mem_block_1_1),
        .mem_block_1_2(mem_block_1_2),

        .mem_loc_in(mem_loc_in),
        .level_2_out(level_2_out),
        .lqd_trigger(lqd_trigger),

        .level_0_0(level_0_0),
        .level_0_1(level_0_1),

        .level_1(level_1)
    );

    // -------------------------------------------------------------------------
    // Dummy checksum to prevent Vivado from optimizing away the DUT
    // -------------------------------------------------------------------------
    assign dummy_checksum = ^{
        out_1,
        mem_block_1_1,
        mem_block_1_2,
        level_2_out,
        lqd_trigger,
        level_1
    };

endmodule