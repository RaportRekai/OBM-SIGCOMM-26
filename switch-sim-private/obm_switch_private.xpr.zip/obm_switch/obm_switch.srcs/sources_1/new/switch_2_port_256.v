module switch_2_port_256 #(
    parameter N = 2,               // Number of Ports
    parameter PD_WIDTH = 10,        // Packet Data Width
    parameter DEPTH_LOG = 10,      
    parameter N_16_WIDTH = 10,
    parameter TOTAL_MEM_CAPACITY = 700, // Total slots
    parameter K = 2 
)(
    // --- Clocks & Reset ---
    //input wire clk_sys,          // <--- REMOVED
    input wire clk_mem,             // Fast Clock (Master TDM Clock)
    input wire rst_n,
    

    // --- Control Inputs (Parallel) ---
    input wire [N-1:0] we_in,       // Write Requests from inputs
    
    // Egress Port Indications
    input wire [255:0] eg_port_in_0,  input wire [255:0] eg_port_in_1,
    
    
    // Output Ports
    output wire [255:0] egress_port_0,  output wire [255:0] egress_port_1,
    
    output wire [7:0] dummy_checksum
);

    // =========================================================================
    // 1. INTERNAL SIGNALS & WIRES
    // =========================================================================
    // TDM Controller Signal (Declared early so we can use it for clock gen)
    reg [$clog2(N)-1:0] tdm_idx;
    //assign clk_sys = tdm_idx[$clog2(N)-1];
    // CLOCK GENERATION (Optimized)
    // tdm_idx loops 0->15. Bit 3 stays LOW for 8 cycles, HIGH for 8 cycles.
    // This creates a clock with Period = 16 * clk_mem period.

 
    wire clk_sys;
    assign clk_sys = tdm_idx[$clog2(N)-1];
    // Rest of signals...
    wire [$clog2(N)-1:0] q_bank_sel [0:N-1];
    wire [(N * PD_WIDTH * N) - 1 : 0] egress_sched_out_flat;
    // WAC Signals
    wire [N-1:0] wac_valid_we; 
    wire [N-1:0] wac_lqd_bit;
    wire [N-1:0] wac_drop_bit;
    wire [N-1:0] long_q_status;
    wire [$clog2(TOTAL_MEM_CAPACITY):0] shared_pool_left;

    // Helper wire to pack eg_ports for the manager module
    wire [N*$clog2(N)-1 : 0] wac_eg_ports_packed;
    assign wac_eg_ports_packed = {
         eg_port_in_1[$clog2(N)-1:0],  eg_port_in_0[$clog2(N)-1:0]
    };
    // Queue Control Signals
    reg [DEPTH_LOG-1:0] write_ptr [0:N-1]; 
    reg [N-1:0] obm_we_a;                  
    reg [DEPTH_LOG-1:0] obm_addr_a [0:N-1];

    wire [N*(DEPTH_LOG)-1 : 0] q_len_flat;

    // Scheduler Signals
    wire [N-1:0] obm_re_b;      
    wire [N-1:0] lqd_trigger;   

    wire [PD_WIDTH-1:0] n_16_data [0:N-1]; 
    wire [(N * PD_WIDTH*N) - 1 : 0] egress_lqd_out_flat;

    wire [$clog2(N):0] drop_amount; 
    wire [N-1:0] q_not_empty;
    wire [N-1:0] final_we_a_packed;
    
    wire [DEPTH_LOG-1:0] q_ptr;
    wire [$clog2(N)-1:0]long_q;
    
    wire [N-1:0]lqd_out_delayed;
    reg [255:0] egress_pkt_count[0:N-1];
    
    assign egress_port_0 = egress_pkt_count[0];
    assign egress_port_1 = egress_pkt_count[1];
    
    assign dummy_checksum = ^egress_sched_out_flat;
    

    // =========================================================================
    // 2. WAC INSTANTIATION (Admission Control)
    // =========================================================================
    wac_2_port #(.N(N), .DEPTH_LOG(DEPTH_LOG),.TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY)) u_wac (
        .clk(clk_sys), // Using bit 3 of tdm_idx
        .we(we_in),
        // Connect inputs explicitly
        .eg_port_0(eg_port_in_0[$clog2(N)-1:0]), .eg_port_1(eg_port_in_1[$clog2(N)-1:0]),
        
        .long_q(long_q), 
        .left(shared_pool_left),
        .lqd_bit_gen(wac_lqd_bit),
        .drop_bit_gen(wac_drop_bit),
        .valid_we(wac_valid_we)
    );

    // =========================================================================
    // 2. PIPELINE DELAY (Modularized)
    // =========================================================================
    wire [N-1:0] delayed_we;            
    wire [N*$clog2(N)-1:0] delayed_eg_ports_flat; 

    pipeline_manager #(.N(N), .K(K)) u_pipeline (
        .clk(clk_sys), // Using bit 3 of tdm_idx
        .rst_n(rst_n),
        .we_in(wac_valid_we),
        .lqd_in(wac_lqd_bit),
        .lqd_out(lqd_out_delayed),
        .dest_in_flat(wac_eg_ports_packed), 
        .we_out(delayed_we),
        .dest_out_flat(delayed_eg_ports_flat)
    );

    // =========================================================================
    // 3. INTERNAL PACKET GENERATOR & TDM CONTROLLER
    // =========================================================================
              
  
    reg [PD_WIDTH-1:0] shared_data_bus; 
    
    integer k;
    localparam PAD_WIDTH = PD_WIDTH - 2*$clog2(N); 

    // 2. Sequential TDM Logic (Clocked by Fast Clock)
    always @(posedge clk_mem or negedge rst_n) begin
        if (!rst_n) begin
            tdm_idx <= 0;
            obm_we_a <= 0;
            shared_data_bus <= 0;
            for (k = 0; k < N; k = k + 1) begin
                egress_pkt_count[k] <= 256'd0;
            end
        end else begin
            // A. Cycle TDM Index (Next Source)
            tdm_idx <= tdm_idx + 1;
            
            // ... Logic continues unchanged ...
            for (k = 0; k < N; k = k + 1) begin
                if (q_not_empty[k]) begin
                    egress_pkt_count[k] <= egress_pkt_count[k] + 1;
                end
            end

            if (lqd_out_delayed[tdm_idx] == 1'b1) begin
                // Case 1: LIQUIDATION EVENT
                shared_data_bus <= { 
                    {(PD_WIDTH - N_16_WIDTH){1'b0}}, 
                    n_16_data[tdm_idx] 
                };
            end else begin
                // Case 2: NORMAL PACKET WRITE
                shared_data_bus <= { 
                    {PAD_WIDTH{1'b0}}, 
                    delayed_eg_ports_flat[ tdm_idx * $clog2(N) +: $clog2(N) ], 
                    tdm_idx 
                };
            end
            // D. Write Decoder
            for (k = 0; k < N; k = k + 1) begin
                obm_we_a[k] <= 1'b0; 
                
                if ( (k == delayed_eg_ports_flat[ tdm_idx* $clog2(N) +: $clog2(N) ]) && delayed_we[tdm_idx] ) begin
                    obm_we_a[k] <= 1'b1;
                end
            end
        end
    end

    // =========================================================================
    // 5. N_16 INSTANTIATION (Congestion Logic)
    // =========================================================================
    
    wire read_pulse = (tdm_idx == N-1);
    
    main_n_2 #(.N(N), .LEVEL($clog2(N)), .WIDTH(N_16_WIDTH),.ADDRESS_WIDTH(PD_WIDTH)) u_n2 (
        .clk(clk_sys), // Using bit 3 of tdm_idx
        .lqd_bit(wac_lqd_bit),
        .mem_loc_in(egress_lqd_out_flat),
        .rst_n(rst_n),
        .out_1(drop_amount),
        .level_2_out(long_q),
        .level_0_0(q_len_flat[0*(DEPTH_LOG) +: N_16_WIDTH]),
        .level_0_1(q_len_flat[1*(DEPTH_LOG) +: N_16_WIDTH]),
        
        .mem_block_1_1(n_16_data[0]),
        .mem_block_1_2(n_16_data[1]),
     
        
        .lqd_trigger(lqd_trigger)
    );
    //==========================================================================
    // Shared Pool Manager
    //==========================================================================
    pool_manager_2 #(
    N,
    DEPTH_LOG,
    TOTAL_MEM_CAPACITY) s_p 
    (
    .clk_mem(clk_mem), // Still uses fast clock, as it interacts with TDM
    .rst_n(rst_n),
    .obm_we_a(final_we_a_packed),
    .lqd_trigger(lqd_trigger),
    .drop_amount(drop_amount),
    .read_pulse(read_pulse),
    .shared_pool_left(shared_pool_left),
    .q_not_empty(q_not_empty),
    .tdm_idx(tdm_idx)
    
    );
    // =========================================================================
    // 6. OBM QUEUES (The Memory)
    // =========================================================================
    
    genvar i;
    generate
        for (i = 0; i < N; i = i + 1) begin : obm_inst
            
            // Priority: LQD Trigger overrides normal write
            assign final_we_a_packed[i] = lqd_trigger[i] ? 1'b0 : obm_we_a[i];

            obm_queue #(
                .PD_WIDTH(PD_WIDTH),
                .N(N),
                .DEPTH_LOG(DEPTH_LOG)
            ) u_queue (
                .clk(clk_mem),
                .rst_n(rst_n),
                
                // Port A (Write / LQD)
                .we_a(final_we_a_packed[i]),
                .din_a(shared_data_bus), 
                .lqd_trigger(lqd_trigger[i]),
                .drop_k(drop_amount),
                
                // Outputs (Slicing the flattened vectors)
                .dout_a(egress_lqd_out_flat[i*(PD_WIDTH*N) +: (PD_WIDTH*N)]), 
                .dout_b(egress_sched_out_flat[i*(PD_WIDTH*N) +: (PD_WIDTH*N)]), 
                
                // Status
                .current_len(q_len_flat[i*(DEPTH_LOG) +: (DEPTH_LOG)]),
                
                // Port B (Read)
                .re_b(read_pulse),
                .valid_out(q_not_empty[i])
                //.tdm_idx(tdm_idx)
            );
        end
    endgenerate

endmodule