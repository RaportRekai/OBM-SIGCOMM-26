module wrapper_n_8 (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    output wire [7:0] dummy_checksum
);

    wire clk_mem;
    wire clk_wiz_locked;

    clk_wiz_4 clk_gen (
        .clk_out1(clk_mem),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    // -------------------------------------------------------------------------
    // Internal stimulus registers
    // These replace the large top-level IOs.
    // -------------------------------------------------------------------------
    reg [7:0] lqd_bit;
    reg [(8 * 6) - 1 : 0] mem_loc_in;

    reg [7:0] level_0_0;
    reg [7:0] level_0_1;
    reg [7:0] level_0_2;
    reg [7:0] level_0_3;
    reg [7:0] level_0_4;
    reg [7:0] level_0_5;
    reg [7:0] level_0_6;
    reg [7:0] level_0_7;

    always @(posedge clk_mem or negedge rst_clean_n) begin
        if (!rst_clean_n) begin
            lqd_bit    <= 8'd0;
            mem_loc_in <= 48'd0;

            level_0_0 <= 8'd0;
            level_0_1 <= 8'd1;
            level_0_2 <= 8'd2;
            level_0_3 <= 8'd3;
            level_0_4 <= 8'd4;
            level_0_5 <= 8'd5;
            level_0_6 <= 8'd6;
            level_0_7 <= 8'd7;
        end else begin
            lqd_bit    <= lqd_bit + 1'b1;
            mem_loc_in <= mem_loc_in + 1'b1;

            level_0_0 <= level_0_0 + 1'b1;
            level_0_1 <= level_0_1 + 2'd2;
            level_0_2 <= level_0_2 + 2'd3;
            level_0_3 <= level_0_3 + 3'd4;
            level_0_4 <= level_0_4 + 3'd5;
            level_0_5 <= level_0_5 + 3'd6;
            level_0_6 <= level_0_6 + 3'd7;
            level_0_7 <= level_0_7 + 4'd8;
        end
    end

    // -------------------------------------------------------------------------
    // DUT outputs
    // -------------------------------------------------------------------------
    wire [3:0] out_3;

    wire [5:0] mem_block_1_1;
    wire [5:0] mem_block_1_2;
    wire [5:0] mem_block_1_3;
    wire [5:0] mem_block_1_4;
    wire [5:0] mem_block_1_5;
    wire [5:0] mem_block_1_6;
    wire [5:0] mem_block_1_7;
    wire [5:0] mem_block_1_8;

    wire [2:0] level_4_out;
    wire [7:0] lqd_trigger;

    wire [10:0] level_3;

    // -------------------------------------------------------------------------
    // DUT instance
    // -------------------------------------------------------------------------
    main_n_8_mod #(
        .N(8),
        .LEVEL(3),
        .ADDRESS_WIDTH(6),
        .WIDTH(8),
        .LEN_WIDTH(8)
    ) uut (
        .clk(clk_mem),
        .rst_n(rst_clean_n),

        .lqd_bit(lqd_bit),

        .out_3(out_3),

        .mem_block_1_1(mem_block_1_1),
        .mem_block_1_2(mem_block_1_2),
        .mem_block_1_3(mem_block_1_3),
        .mem_block_1_4(mem_block_1_4),
        .mem_block_1_5(mem_block_1_5),
        .mem_block_1_6(mem_block_1_6),
        .mem_block_1_7(mem_block_1_7),
        .mem_block_1_8(mem_block_1_8),

        .mem_loc_in(mem_loc_in),
        .level_4_out(level_4_out),
        .lqd_trigger(lqd_trigger),

        .level_0_0(level_0_0),
        .level_0_1(level_0_1),
        .level_0_2(level_0_2),
        .level_0_3(level_0_3),
        .level_0_4(level_0_4),
        .level_0_5(level_0_5),
        .level_0_6(level_0_6),
        .level_0_7(level_0_7),

        .level_3(level_3)
    );

    // -------------------------------------------------------------------------
    // Dummy checksum to prevent Vivado from optimizing away the DUT
    // -------------------------------------------------------------------------
    assign dummy_checksum = ^{
        out_3,
        mem_block_1_1,
        mem_block_1_2,
        mem_block_1_3,
        mem_block_1_4,
        mem_block_1_5,
        mem_block_1_6,
        mem_block_1_7,
        mem_block_1_8,
        level_4_out,
        lqd_trigger,
        level_3
    };

endmodule