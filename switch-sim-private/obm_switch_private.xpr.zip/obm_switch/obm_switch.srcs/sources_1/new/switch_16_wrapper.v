module port_16_wrapper (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    input  wire [15:0] we_in,

    input wire [3:0] eg_port_in_0,
    input wire [3:0] eg_port_in_1,
    input wire [3:0] eg_port_in_2,
    input wire [3:0] eg_port_in_3,
    input wire [3:0] eg_port_in_4,
    input wire [3:0] eg_port_in_5,
    input wire [3:0] eg_port_in_6,
    input wire [3:0] eg_port_in_7,
    input wire [3:0] eg_port_in_8,
    input wire [3:0] eg_port_in_9,
    input wire [3:0] eg_port_in_10,
    input wire [3:0] eg_port_in_11,
    input wire [3:0] eg_port_in_12,
    input wire [3:0] eg_port_in_13,
    input wire [3:0] eg_port_in_14,
    input wire [3:0] eg_port_in_15,

    output wire [15:0] egress_port_0,
    output wire [15:0] egress_port_1,
    output wire [15:0] egress_port_2,
    output wire [15:0] egress_port_3,
    output wire [15:0] egress_port_4,
    output wire [15:0] egress_port_5,
    output wire [15:0] egress_port_6,
    output wire [15:0] egress_port_7,
    output wire [15:0] egress_port_8,
    output wire [15:0] egress_port_9,
    output wire [15:0] egress_port_10,
    output wire [15:0] egress_port_11,
    output wire [15:0] egress_port_12,
    output wire [15:0] egress_port_13,
    output wire [15:0] egress_port_14,
    output wire [15:0] egress_port_15,

    output wire [7:0] dummy_checksum
);

    wire clk_195;        // clk_out1 = 195.3125 MHz
    wire clk_24;         // clk_out2 = 24.4140625 MHz
    wire clk_wiz_locked;

    clk_wiz_2 clk_gen (
        .clk_out1(clk_195),
        .clk_out2(clk_24),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    switch_top uut (
        .clk_mem(clk_195),
        .clk_sys(clk_24),
        .rst_n(rst_clean_n),

        .we_in(we_in),

        .eg_port_in_0(eg_port_in_0),
        .eg_port_in_1(eg_port_in_1),
        .eg_port_in_2(eg_port_in_2),
        .eg_port_in_3(eg_port_in_3),
        .eg_port_in_4(eg_port_in_4),
        .eg_port_in_5(eg_port_in_5),
        .eg_port_in_6(eg_port_in_6),
        .eg_port_in_7(eg_port_in_7),
        .eg_port_in_8(eg_port_in_8),
        .eg_port_in_9(eg_port_in_9),
        .eg_port_in_10(eg_port_in_10),
        .eg_port_in_11(eg_port_in_11),
        .eg_port_in_12(eg_port_in_12),
        .eg_port_in_13(eg_port_in_13),
        .eg_port_in_14(eg_port_in_14),
        .eg_port_in_15(eg_port_in_15),

        .egress_port_0(egress_port_0),
        .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),
        .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),
        .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),
        .egress_port_7(egress_port_7),
        .egress_port_8(egress_port_8),
        .egress_port_9(egress_port_9),
        .egress_port_10(egress_port_10),
        .egress_port_11(egress_port_11),
        .egress_port_12(egress_port_12),
        .egress_port_13(egress_port_13),
        .egress_port_14(egress_port_14),
        .egress_port_15(egress_port_15),

        .dummy_checksum(dummy_checksum)
    );

endmodule