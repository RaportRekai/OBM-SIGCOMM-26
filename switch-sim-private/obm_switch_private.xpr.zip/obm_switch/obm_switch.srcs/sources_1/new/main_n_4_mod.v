module main_n_4_mod  #(
            parameter N = 4,
            parameter LEVEL = $clog2(N), // 2
            parameter ADDRESS_WIDTH = 6,
            parameter WIDTH = 8,
            parameter LEN_WIDTH = 8
        ) (
            input clk,
            input rst_n,
            input [N-1:0] lqd_bit,
            
            output [LEVEL:0] out_2, // Total active count

            output [ADDRESS_WIDTH -1:0] mem_block_1_1,
            output [ADDRESS_WIDTH -1:0] mem_block_1_2,
            output [ADDRESS_WIDTH -1:0] mem_block_1_3,
            output [ADDRESS_WIDTH -1:0] mem_block_1_4,

            input [(N * ADDRESS_WIDTH) - 1 : 0] mem_loc_in,
            output wire [$clog2(N)-1:0] level_3_out,
            output wire [N-1:0] lqd_trigger,
            
            input [WIDTH-1:0] level_0_0,
            input [WIDTH-1:0] level_0_1,
            input [WIDTH-1:0] level_0_2,
            input [WIDTH-1:0] level_0_3,
            
            output [WIDTH-1+$clog2(N):0] level_2
            );

  // --------------------------------------------------------
  // 1. Internal Wires & Registers
  // --------------------------------------------------------
  wire [1:0] out_1 [N/2-1:0];

  // Delay Lines
  reg         pair_list_r_a_1 [0:N/2-1] [0:3]; // Depth 2 for bottom bits
  reg [1:0]   pair_list_r_a_2 [0:N/4-1][0:1];       // Depth 1 (Single reg) for Level 2

  reg [N*ADDRESS_WIDTH-1:0] mem;
  wire [N/2*ADDRESS_WIDTH-1:0] mem_block_2 [N/2-1:0]; 
  wire [N/4*ADDRESS_WIDTH-1:0] mem_block_1 [N-1:0];   

  wire [N/2-1:0] control_2; 
  wire [N/4-1:0] control_1 [N/2-1:0];

  wire [WIDTH-1+$clog2(N):0] level_1 [N/2-1:0];
  wire [WIDTH-1:0] level_0 [N-1:0];
  assign level_0[0] = level_0_0; assign level_0[1] = level_0_1;
  assign level_0[2] = level_0_2; assign level_0[3] = level_0_3;

  // Zero Latency Memory Select
  
  
  assign lqd_trigger = (out_2 > 0) ? (1'b1 << level_2[$clog2(N)-1:0]) : {N{1'b0}};
  assign level_3_out = level_2[$clog2(N)-1:0];

  assign mem_block_1_1 = mem_block_1[0];
  assign mem_block_1_2 = mem_block_1[1];
  assign mem_block_1_3 = mem_block_1[2];
  assign mem_block_1_4 = mem_block_1[3];

  // --------------------------------------------------------
  // 2. Adder Tree
  // --------------------------------------------------------
  generate
    genvar i;
    for (i = 0; i < N; i = i + 2) begin : adder_level_0
        adder_1 #(.WIDTH(1)) a1 (
            .clk(clk), .a(lqd_bit[i]), .b(lqd_bit[i + 1]), .out(out_1[i / 2])
        );
    end
    for (i = 0; i < N/4; i = i + 1) begin : adder_level_1
        adder_1 #(.WIDTH(2)) a2 (
            .clk(clk), .a(out_1[2*i]), .b(out_1[2*i+1]), .out(out_2)
        );
    end
  endgenerate

  // --------------------------------------------------------
  // 3. Address Steering Logic
  // --------------------------------------------------------
  generate
    genvar k, j;
    
    // LEVEL 2: Top Split (4 ports -> 2 Left / 2 Right)
    // Left
    add_select #(.TOT(N), .ADDRESS_WIDTH(ADDRESS_WIDTH)) adl (
          .clk(clk), .ctrl(control_2), .mem(mem), .mem_block(mem_block_2[0]) 
    );
    ControlLUT #(N/2, $clog2(N/2)) c1 (pair_list_r_a_2[0][1], control_2);

    // Right (Needs 2 Muxes for 2 blocks)
    for (k=0; k < N/2; k=k+1) begin : top_mux
        mux_address #(
            .START(k), .END(k+N/2), .TOT(2*N), .ADDRESS_WIDTH(ADDRESS_WIDTH)
        ) ma1 (
            .clk(clk),
            .cntrl(pair_list_r_a_2[0][1]), 
            .memory(mem[ (N*ADDRESS_WIDTH)-1 : k*ADDRESS_WIDTH ]), 
            .mem_block_1(mem_block_2[1][(k+1)*ADDRESS_WIDTH-1 : k*ADDRESS_WIDTH])
        );
    end

    // LEVEL 1: Bottom Split (2 ports -> 1 Left / 1 Right)
    for (j=0; j<N/2; j=j+1) begin : demux_bot
        // Left
        add_select #(.TOT(N/2), .ADDRESS_WIDTH(ADDRESS_WIDTH)) ad_bot (
            .clk(clk), .ctrl(control_1[j]), .mem(mem_block_2[j]), .mem_block(mem_block_1[2*j])
        );
        ControlLUT #(N/4, $clog2(N/4)) c2 (pair_list_r_a_1[j][3], control_1[j]);

        // Right (1 Mux)
        mux_address #(
            .START(0), .END(1), .TOT(N), .ADDRESS_WIDTH(ADDRESS_WIDTH)
        ) ma_bot (
            .clk(clk),
            .cntrl(pair_list_r_a_1[j][3]), 
            .memory(mem_block_2[j]), 
            .mem_block_1(mem_block_1[2*j+1])
        );
    end
  endgenerate

  // --------------------------------------------------------
  // 4. Comparator Tree
  // --------------------------------------------------------
  generate
    for (i = 0; i < N/2; i = i + 1) begin : level_0_to_1
        wire [LEVEL-1:0] id_a = (2*i);
        wire [LEVEL-1:0] id_b = (2*i + 1);
        comparator #(.WIDTH(WIDTH), .LEVEL($clog2(N)), .N(N)) comp1 (
            .clk(clk), .a({level_0[2*i], id_a}), .b({level_0[2*i+1], id_b}), .greater(level_1[i])
        );
    end
    for (i = 0; i < N/4; i = i + 1) begin : level_1_to_2
        comparator #(.WIDTH(WIDTH), .LEVEL($clog2(N)), .N(N)) comp2 (
            .clk(clk), .a(level_1[2*i]), .b(level_1[2*i+1]), .greater(level_2)
        );
    end
  endgenerate

  // --------------------------------------------------------
  // 5. Sequential Logic
  // --------------------------------------------------------
  integer g, t;
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
        // 1. RESET CONDITION (Active Low)
        // You MUST clear your registers here
       
        // Reset Delay Line 1
        for(g=0; g<N; g=g+2) begin
            pair_list_r_a_1[g/2][0] <= 1'b0;
            pair_list_r_a_1[g/2][1] <= 1'b0;
            pair_list_r_a_1[g/2][2] <= 1'b0;
            pair_list_r_a_1[g/2][3] <= 1'b0;
        end
        
        // Reset Delay Line 2
        for(g=0; g<N/4; g=g+2) begin
            pair_list_r_a_2[g/2][0] <= 2'b0;
            pair_list_r_a_2[g/2][1] <= 2'b1;
        end

    end else begin
        // 2. NORMAL OPERATION (Clocked)
        // This is your original logic
         mem <= mem_loc_in[0 +: (ADDRESS_WIDTH*N)];
        // Delay Line 1 (lqd_bit) -> Depth 2
        for(g=0; g<N; g=g+2) begin
            pair_list_r_a_1[g/2][0] <= lqd_bit[g];
            pair_list_r_a_1[g/2][1] <= pair_list_r_a_1[g/2][0];
            pair_list_r_a_1[g/2][2] <= pair_list_r_a_1[g/2][1];
            pair_list_r_a_1[g/2][3] <= pair_list_r_a_1[g/2][2];
        end
        
        // Delay Line 2 (out_1) -> Depth 1
        for(g=0; g<N/4; g=g+2) begin
            pair_list_r_a_2[g/2][0] <= out_1[g];
            pair_list_r_a_2[g/2][1] <= pair_list_r_a_2[g/2][0];
        end
    end
  end

endmodule