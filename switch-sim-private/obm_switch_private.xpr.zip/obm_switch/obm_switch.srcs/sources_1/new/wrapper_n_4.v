module wrapper_n_4 (
    input  wire clk_mem_p,   // physical 300 MHz differential board clock +
    input  wire clk_mem_n,   // physical 300 MHz differential board clock -
    input  wire rst_n,

    output wire [7:0] dummy_checksum
);

    wire clk_mem;
    wire clk_wiz_locked;

    clk_wiz_5 clk_gen (
        .clk_out1(clk_mem),

        .reset(~rst_n),
        .locked(clk_wiz_locked),

        .clk_in1_p(clk_mem_p),
        .clk_in1_n(clk_mem_n)
    );

    wire rst_clean_n;
    assign rst_clean_n = rst_n & clk_wiz_locked;

    // -------------------------------------------------------------------------
    // Internal stimulus registers
    // These replace the large top-level IOs.
    // -------------------------------------------------------------------------
    reg [3:0] lqd_bit;
    reg [(4 * 6 ) - 1 : 0] mem_loc_in;

    reg [7:0] level_0_0;
    reg [7:0] level_0_1;
    reg [7:0] level_0_2;
    reg [7:0] level_0_3;

    always @(posedge clk_mem or negedge rst_clean_n) begin
        if (!rst_clean_n) begin
            lqd_bit    <= 4'd0;
            mem_loc_in <= 24'd0;

            level_0_0 <= 8'd0;
            level_0_1 <= 8'd1;
            level_0_2 <= 8'd2;
            level_0_3 <= 8'd3;
        end else begin
            lqd_bit    <= lqd_bit + 1'b1;
            mem_loc_in <= mem_loc_in + 1'b1;

            level_0_0 <= level_0_0 + 1'b1;
            level_0_1 <= level_0_1 + 2'd2;
            level_0_2 <= level_0_2 + 2'd3;
            level_0_3 <= level_0_3 + 3'd4;
        end
    end

    // -------------------------------------------------------------------------
    // DUT outputs
    // -------------------------------------------------------------------------
    wire [2:0] out_2;

    wire [5:0] mem_block_1_1;
    wire [5:0] mem_block_1_2;
    wire [5:0] mem_block_1_3;
    wire [5:0] mem_block_1_4;

    wire [1:0] level_3_out;
    wire [3:0] lqd_trigger;

    wire [10:0] level_2;

    // -------------------------------------------------------------------------
    // DUT instance
    // -------------------------------------------------------------------------
    main_n_4_mod #(
        .N(4),
        .LEVEL(2),
        .ADDRESS_WIDTH(6),
        .WIDTH(8),
        .LEN_WIDTH(8)
    ) uut (
        .clk(clk_mem),
        .rst_n(rst_clean_n),

        .lqd_bit(lqd_bit),

        .out_2(out_2),

        .mem_block_1_1(mem_block_1_1),
        .mem_block_1_2(mem_block_1_2),
        .mem_block_1_3(mem_block_1_3),
        .mem_block_1_4(mem_block_1_4),

        .mem_loc_in(mem_loc_in),
        .level_3_out(level_3_out),
        .lqd_trigger(lqd_trigger),

        .level_0_0(level_0_0),
        .level_0_1(level_0_1),
        .level_0_2(level_0_2),
        .level_0_3(level_0_3),

        .level_2(level_2)
    );

    // -------------------------------------------------------------------------
    // Dummy checksum to prevent Vivado from optimizing away the DUT
    // -------------------------------------------------------------------------
    assign dummy_checksum = ^{
        out_2,
        mem_block_1_1,
        mem_block_1_2,
        mem_block_1_3,
        mem_block_1_4,
        level_3_out,
        lqd_trigger,
        level_2
    };

endmodule