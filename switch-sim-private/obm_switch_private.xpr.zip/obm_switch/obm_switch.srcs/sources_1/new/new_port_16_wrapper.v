module new_16_port_wrapper #(
    parameter N = 16,
    parameter PD_WIDTH = 13,
    parameter DEPTH_LOG = 13,
    parameter N_16_WIDTH = 13,
    parameter TOTAL_MEM_CAPACITY = 5594,
    parameter K = 8
)(
    // Differential input clock
    input wire clk_in1_p,
    input wire clk_in1_n,

    // External active-low reset
    input wire rst_n,

    // Control inputs
    input wire [N-1:0] we_in,

    input wire [3:0] eg_port_in_0,  input wire [3:0] eg_port_in_1,
    input wire [3:0] eg_port_in_2,  input wire [3:0] eg_port_in_3,
    input wire [3:0] eg_port_in_4,  input wire [3:0] eg_port_in_5,
    input wire [3:0] eg_port_in_6,  input wire [3:0] eg_port_in_7,
    input wire [3:0] eg_port_in_8,  input wire [3:0] eg_port_in_9,
    input wire [3:0] eg_port_in_10, input wire [3:0] eg_port_in_11,
    input wire [3:0] eg_port_in_12, input wire [3:0] eg_port_in_13,
    input wire [3:0] eg_port_in_14, input wire [3:0] eg_port_in_15,

    // Output ports
    output wire [15:0] egress_port_0,  output wire [15:0] egress_port_1,
    output wire [15:0] egress_port_2,  output wire [15:0] egress_port_3,
    output wire [15:0] egress_port_4,  output wire [15:0] egress_port_5,
    output wire [15:0] egress_port_6,  output wire [15:0] egress_port_7,
    output wire [15:0] egress_port_8,  output wire [15:0] egress_port_9,
    output wire [15:0] egress_port_10, output wire [15:0] egress_port_11,
    output wire [15:0] egress_port_12, output wire [15:0] egress_port_13,
    output wire [15:0] egress_port_14, output wire [15:0] egress_port_15,

    output wire [7:0] dummy_checksum
);

    // -------------------------------------------------------------------------
    // Clocking Wizard signals
    // -------------------------------------------------------------------------
    wire clk_out1;
    wire locked;

    // Clocking Wizard reset is active-high
    wire reset;
    assign reset = ~rst_n;

    // Keep DUT in reset until clock wizard is locked
    wire dut_rst_n;
    assign dut_rst_n = rst_n & locked;

    // -------------------------------------------------------------------------
    // Clocking Wizard instance
    // -------------------------------------------------------------------------
    clk_wiz_2 instance_name (
        // Clock out ports
        .clk_out1(clk_out1),

        // Status and control signals
        .reset(reset),
        .locked(locked),

        // Differential clock input ports
        .clk_in1_p(clk_in1_p),
        .clk_in1_n(clk_in1_n)
    );

    // -------------------------------------------------------------------------
    // Original switch design
    // -------------------------------------------------------------------------
    switch_top #(
        .N(N),
        .PD_WIDTH(PD_WIDTH),
        .DEPTH_LOG(DEPTH_LOG),
        .N_16_WIDTH(N_16_WIDTH),
        .TOTAL_MEM_CAPACITY(TOTAL_MEM_CAPACITY),
        .K(K)
    ) u_switch_top (
        .clk_mem(clk_out1),
        .rst_n(dut_rst_n),

        .we_in(we_in),

        .eg_port_in_0(eg_port_in_0),
        .eg_port_in_1(eg_port_in_1),
        .eg_port_in_2(eg_port_in_2),
        .eg_port_in_3(eg_port_in_3),
        .eg_port_in_4(eg_port_in_4),
        .eg_port_in_5(eg_port_in_5),
        .eg_port_in_6(eg_port_in_6),
        .eg_port_in_7(eg_port_in_7),
        .eg_port_in_8(eg_port_in_8),
        .eg_port_in_9(eg_port_in_9),
        .eg_port_in_10(eg_port_in_10),
        .eg_port_in_11(eg_port_in_11),
        .eg_port_in_12(eg_port_in_12),
        .eg_port_in_13(eg_port_in_13),
        .eg_port_in_14(eg_port_in_14),
        .eg_port_in_15(eg_port_in_15),

        .egress_port_0(egress_port_0),
        .egress_port_1(egress_port_1),
        .egress_port_2(egress_port_2),
        .egress_port_3(egress_port_3),
        .egress_port_4(egress_port_4),
        .egress_port_5(egress_port_5),
        .egress_port_6(egress_port_6),
        .egress_port_7(egress_port_7),
        .egress_port_8(egress_port_8),
        .egress_port_9(egress_port_9),
        .egress_port_10(egress_port_10),
        .egress_port_11(egress_port_11),
        .egress_port_12(egress_port_12),
        .egress_port_13(egress_port_13),
        .egress_port_14(egress_port_14),
        .egress_port_15(egress_port_15),

        .dummy_checksum(dummy_checksum)
    );

endmodule